# 🏢 MU Gateway - Multi-Utility Payment Solution

A comprehensive Java-based utility bill payment system that allows users to pay electricity, water, gas, mobile, internet, and DTH bills in one convenient platform.

---

## 📋 Table of Contents

- [Features](#features)
- [Project Structure](#project-structure)
- [Prerequisites](#prerequisites)
- [Installation & Setup](#installation--setup)
- [Database Schema](#database-schema)
- [Usage Guide](#usage-guide)
- [Technologies Used](#technologies-used)
- [API Endpoints](#api-endpoints)
- [Troubleshooting](#troubleshooting)
- [Future Enhancements](#future-enhancements)

---

## ✨ Features

### 👤 User Management
- ✅ User registration and login
- ✅ Wallet management (add/withdraw money)
- ✅ Profile updates
- ✅ Transaction history

### 💳 Bill Payment
- ✅ View all bills
- ✅ Filter unpaid bills
- ✅ Multiple payment methods:
  - 📱 UPI
  - 💳 Credit Card
  - 🏦 Debit Card
  - 🌐 Net Banking
  - 💼 Wallet
  - 💵 Cash (Offline)
- ✅ Payment confirmation via email
- ✅ Receipt generation

### 📊 Admin Panel
- ✅ Manage users
- ✅ Manage bills
- ✅ Manage utilities
- ✅ View transactions
- ✅ Generate reports

### 📧 Email Notifications
- ✅ Welcome email on registration
- ✅ Payment confirmation email
- ✅ Password reset email
- ✅ Bill due reminder

---

## 📁 Project Structure

MU-Gateway/
│
├── src/
│   └── com/mugateway/
│       ├── dao/
│       │   ├── UserDAO.java
│       │   ├── BillDAO.java
│       │   ├── UtilityDAO.java
│       │   ├── TransactionDAO.java
│       │   └── DatabaseConnection.java
│       │
│       ├── model/
│       │   ├── User.java
│       │   ├── Bill.java
│       │   ├── Utility.java
│       │   ├── Transaction.java
│       │   └── PaymentMethod.java
│       │
│       ├── service/
│       │   ├── UserService.java
│       │   ├── BillService.java
│       │   ├── UtilityService.java
│       │   ├── TransactionService.java
│       │   ├── PaymentService.java
│       │   └── WalletService.java
│       │
│       ├── util/
│       │   ├── EmailService.java
│       │   ├── ValidationUtil.java
│       │   ├── SecurityUtil.java
│       │   ├── DateUtil.java
│       │   └── Constants.java
│       │
│       └── app/
│           ├── MainApp.java
│           └── AdminApp.java
│
├── lib/
│   ├── mysql-connector-java-8.0.x.jar
│   └── mail.jar
│
├── database/
│   └── mugateway_schema.sql
│
├── config/
│   └── database.properties
│
├── logs/
│   └── app.log
│
└── README.md


---

## 🔧 Prerequisites

- **Java**: JDK 8 or higher
- **MySQL**: Version 5.7 or higher
- **IDE**: Eclipse, IntelliJ IDEA, or NetBeans
- **Email**: Gmail account with App Password

---

## 🚀 Installation & Setup

### Step 1: Clone or Download Project

```bash
git clone https://github.com/yourusername/MU-Gateway.git
cd MU-Gateway

Step 2: Set Up Database
Open MySQL Workbench or MySQL Command Line
Run the SQL script:
mysql -u root -p < database/mugateway_schema.sql

Or manually:

CREATE DATABASE mugateway;
USE mugateway;

-- Copy all SQL from database/mugateway_schema.sql

Step 3: Configure Database Connection
Edit src/com/mugateway/dao/DatabaseConnection.java:

private static final String DB_URL = "jdbc:mysql://localhost:3306/mugateway";
private static final String DB_USER = "root";
private static final String DB_PASSWORD = "your_password";

Step 4: Configure Email Service
Edit src/com/mugateway/util/EmailService.java:

private static final String SENDER_EMAIL = "your_gmail@gmail.com";
private static final String SENDER_PASSWORD = "your_app_password";

Get Gmail App Password:

Go to https://myaccount.google.com/apppasswords
Select Mail and Windows Computer
Google generates a 16-character password
Copy and paste in EmailService.java
Step 5: Add JAR Files to Eclipse
Add MySQL Connector:

Right-click project → Build Path → Configure Build Path
Click Libraries tab
Click Add External JARs
Select mysql-connector-java-8.0.x.jar from lib/ folder
Click Apply and Close
Add JavaMail JAR:

Same process for mail.jar and activation.jar

Step 6: Run the Application
java -cp bin:lib/* com.mugateway.app.MainApp

Or run from Eclipse:

Right-click MainApp.java
Select Run As → Java Application
🗄️ Database Schema
Users Table
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20) UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    address VARCHAR(255),
    wallet_balance DECIMAL(10, 2) DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

Bills Table
CREATE TABLE bills (
    bill_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    utility_id INT NOT NULL,
    bill_number VARCHAR(50) UNIQUE NOT NULL,
    bill_amount DECIMAL(10, 2) NOT NULL,
    bill_date DATE,
    due_date DATE,
    bill_status ENUM('UNPAID', 'PAID', 'OVERDUE') DEFAULT 'UNPAID',
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (utility_id) REFERENCES utilities(utility_id)
);

Utilities Table
CREATE TABLE utilities (
    utility_id INT PRIMARY KEY AUTO_INCREMENT,
    utility_name VARCHAR(100) NOT NULL,
    utility_type ENUM('ELECTRICITY', 'WATER', 'GAS', 'MOBILE_RECHARGE', 'INTERNET', 'DTH') NOT NULL,
    provider_name VARCHAR(100),
    description TEXT,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

Transactions Table
CREATE TABLE transactions (
    transaction_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    bill_id INT,
    amount DECIMAL(10, 2) NOT NULL,
    transaction_type ENUM('PAYMENT', 'REFUND', 'TOP_UP', 'WITHDRAWAL') DEFAULT 'PAYMENT',
    payment_method VARCHAR(50),
    status ENUM('SUCCESS', 'FAILED', 'PENDING') DEFAULT 'PENDING',
    reference_id VARCHAR(100),
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (bill_id) REFERENCES bills(bill_id)
);

📖 Usage Guide
For Users
1️⃣ Register Account

Welcome to MU Gateway
1. Login
2. Register

→ Select: 2
→ Enter username, email, phone, password, name, address
→ Account created successfully!

2️⃣ Login

→ Select: 1
→ Enter username and password
→ Logged in successfully!

3️⃣ View Bills

Main Menu:
1. View My Bills

→ Select: 1
→ See all your bills with amounts and due dates

4️⃣ Pay Bills

Main Menu:
2. 💳 Pay Bills

Pay Bills Menu:
1. Pay a Specific Bill
2. Make Direct Payment

→ Select: 1
→ Choose bill from list
→ Select payment method
→ Payment successful!

5️⃣ Manage Wallet

Main Menu:
3. Wallet Management

Wallet Menu:
1. Check Balance
2. Add Money
3. Withdraw Money

→ Follow prompts

For Admin
1️⃣ Access Admin Panel

Main Menu:
3. Admin Panel
→ Enter admin password

2️⃣ Manage Users

Admin Menu:
1. Manage Users
→ View all users
→ Update user info
→ Deactivate users

3️⃣ Manage Bills

Admin Menu:
2. Manage Bills
→ Create bills for users
→ Update bill status
→ View all bills

🛠️ Technologies Used
📡 API Endpoints (For Future REST API)
POST   /api/users/register          - Register new user
POST   /api/users/login             - User login
GET    /api/users/{userId}          - Get user details
PUT    /api/users/{userId}          - Update user

GET    /api/bills/{userId}          - Get user bills
GET    /api/bills/{billId}          - Get bill details
POST   /api/bills                   - Create bill (Admin)
PUT    /api/bills/{billId}          - Update bill (Admin)

POST   /api/transactions            - Create transaction
GET    /api/transactions/{userId}   - Get user transactions

POST   /api/payments                - Process payment
GET    /api/payments/{paymentId}    - Get payment status

🐛 Troubleshooting
Problem: "Connection refused" Error
Solution:

1. Check if MySQL is running
   - Windows: Services → MySQL → Start
   - Linux: sudo service mysql start
   - Mac: brew services start mysql-community-server

2. Verify database.properties settings
3. Check MySQL username and password

Problem: "No suitable driver found" Error
Solution:

1. Add mysql-connector-java JAR to Build Path
2. Right-click project → Build Path → Configure Build Path
3. Add mysql-connector-java-8.0.x.jar from lib/ folder
4. Apply and Close

Problem: Email not sending
Solution:

1. Enable "Less secure app access" on Gmail
   - Go to myaccount.google.com/lesssecureapps
   - Turn ON "Allow less secure apps"

2. Or use App Password:
   - Go to myaccount.google.com/apppasswords
   - Generate new App Password
   - Use in EmailService.java

Problem: SQL Error on first run
Solution:

1. Make sure database/mugateway_schema.sql is executed
2. Check all tables are created:
   SELECT * FROM information_schema.tables WHERE table_schema = 'mugateway';

🚀 Future Enhancements
[ ] REST API implementation
[ ] Web-based dashboard (Spring Boot + React)
[ ] Mobile app (Android/iOS)
[ ] SMS notifications
[ ] Real-time payment gateway integration (Razorpay, PayPal)
[ ] Bill auto-pay feature
[ ] Multiple language support
[ ] Advanced analytics and reporting
[ ] Two-factor authentication (2FA)
[ ] Payment history graphs
📧 Support
For issues or questions:

Create an issue on GitHub
Email: chethanhs9481@gmail.com
Call: +91-9481586616
📄 License
This project is licensed under the MIT License - see the LICENSE file for details.

👨‍💻 Author
Chethan H S,
Megha H S
Aviraa

GitHub- Chethan H S : https://github.com/9481586616/Chethan-H-S.git
GitHub- Megha H S:https://github.com/meghasunitha913-boop
GitHub- Aviraa:https://www.google.com/url?q=https://github.com/aviirra&sa=D&source=editors&ust=1772560186084316&usg=AOvVaw2QDIGzbus3ECuUmHVUnLUW

Email-Chethan H S: chethanhs9481@gmail.com
Email-Megha H S:megham_25mcds@acharya.ac.in
Email-Aviraa:aviras_25bmca@acharya.ac.in



🙏 Acknowledgments
Thanks to the Java community
MySQL for database support
Gmail for email services
Last Updated: January 2024
Version: 1.0.0

