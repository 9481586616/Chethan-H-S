package com.mugateway.dao;

import com.mugateway.config.DBConfig;
import com.mugateway.model.Utility;
import com.mugateway.model.Utility.UtilityType;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UtilityDAO {

    // CREATE - Add new utility
    public boolean createUtility(Utility utility) {
        String sql = "INSERT INTO utilities (utility_name, utility_type, provider_name, description) " +
                     "VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, utility.getUtilityName());
            stmt.setString(2, utility.getUtilityType().name());
            stmt.setString(3, utility.getProviderName());
            stmt.setString(4, utility.getDescription());
            
            int affectedRows = stmt.executeUpdate();
            
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        utility.setUtilityId(generatedKeys.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error creating utility: " + e.getMessage());
        }
        return false;
    }

    // READ - Get utility by ID
    public Utility getUtilityById(int utilityId) {
        String sql = "SELECT * FROM utilities WHERE utility_id = ?";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, utilityId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToUtility(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting utility: " + e.getMessage());
        }
        return null;
    }

    // READ - Get all utilities
    public List<Utility> getAllUtilities() {
        List<Utility> utilities = new ArrayList<>();
        String sql = "SELECT * FROM utilities WHERE is_active = TRUE ORDER BY utility_type, utility_name";
        
        try (Connection conn = DBConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                utilities.add(mapResultSetToUtility(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error getting utilities: " + e.getMessage());
        }
        return utilities;
    }

    // READ - Get utilities by type
    public List<Utility> getUtilitiesByType(UtilityType type) {
        List<Utility> utilities = new ArrayList<>();
        String sql = "SELECT * FROM utilities WHERE utility_type = ? AND is_active = TRUE ORDER BY utility_name";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, type.name());
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    utilities.add(mapResultSetToUtility(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting utilities by type: " + e.getMessage());
        }
        return utilities;
    }

    // UPDATE - Update utility
    public boolean updateUtility(Utility utility) {
        String sql = "UPDATE utilities SET utility_name = ?, utility_type = ?, " +
                     "provider_name = ?, description = ? WHERE utility_id = ?";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, utility.getUtilityName());
            stmt.setString(2, utility.getUtilityType().name());
            stmt.setString(3, utility.getProviderName());
            stmt.setString(4, utility.getDescription());
            stmt.setInt(5, utility.getUtilityId());
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating utility: " + e.getMessage());
        }
        return false;
    }

    // DELETE - Deactivate utility (soft delete)
    public boolean deactivateUtility(int utilityId) {
        String sql = "UPDATE utilities SET is_active = FALSE WHERE utility_id = ?";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, utilityId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deactivating utility: " + e.getMessage());
        }
        return false;
    }

    // DELETE - Permanently delete utility
    public boolean deleteUtility(int utilityId) {
        String sql = "DELETE FROM utilities WHERE utility_id = ?";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, utilityId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting utility: " + e.getMessage());
        }
        return false;
    }

    // Helper method
    private Utility mapResultSetToUtility(ResultSet rs) throws SQLException {
        Utility utility = new Utility();
        utility.setUtilityId(rs.getInt("utility_id"));
        utility.setUtilityName(rs.getString("utility_name"));
        utility.setUtilityType(UtilityType.valueOf(rs.getString("utility_type")));
        utility.setProviderName(rs.getString("provider_name"));
        utility.setDescription(rs.getString("description"));
        utility.setActive(rs.getBoolean("is_active"));
        utility.setCreatedAt(rs.getTimestamp("created_at"));
        return utility;
    }
}