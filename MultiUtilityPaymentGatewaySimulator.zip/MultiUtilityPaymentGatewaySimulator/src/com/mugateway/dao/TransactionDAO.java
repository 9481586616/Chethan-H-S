package com.mugateway.dao;

import com.mugateway.config.DBConfig;
import com.mugateway.model.Transaction;
import com.mugateway.model.Transaction.TransactionType;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TransactionDAO {

    // CREATE - Record new transaction
    public boolean createTransaction(Transaction transaction) {
        String sql = "INSERT INTO transactions (user_id, payment_id, transaction_type, amount, " +
                     "balance_before, balance_after, description) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, transaction.getUserId());
            if (transaction.getPaymentId() != null) {
                stmt.setInt(2, transaction.getPaymentId());
            } else {
                stmt.setNull(2, Types.INTEGER);
            }
            stmt.setString(3, transaction.getTransactionType().name());
            stmt.setBigDecimal(4, transaction.getAmount());
            stmt.setBigDecimal(5, transaction.getBalanceBefore());
            stmt.setBigDecimal(6, transaction.getBalanceAfter());
            stmt.setString(7, transaction.getDescription());
            
            int affectedRows = stmt.executeUpdate();
            
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        transaction.setTransactionId(generatedKeys.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error creating transaction: " + e.getMessage());
        }
        return false;
    }

    // READ - Get transaction by ID
    public Transaction getTransactionById(int transactionId) {
        String sql = "SELECT t.*, u.username, p.transaction_ref " +
                     "FROM transactions t " +
                     "JOIN users u ON t.user_id = u.user_id " +
                     "LEFT JOIN payments p ON t.payment_id = p.payment_id " +
                     "WHERE t.transaction_id = ?";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, transactionId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToTransaction(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting transaction: " + e.getMessage());
        }
        return null;
    }

    // READ - Get all transactions for a user
    public List<Transaction> getTransactionsByUserId(int userId) {
        List<Transaction> transactions = new ArrayList<>();
        String sql = "SELECT t.*, u.username, p.transaction_ref " +
                     "FROM transactions t " +
                     "JOIN users u ON t.user_id = u.user_id " +
                     "LEFT JOIN payments p ON t.payment_id = p.payment_id " +
                     "WHERE t.user_id = ? ORDER BY t.transaction_date DESC";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    transactions.add(mapResultSetToTransaction(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting transactions: " + e.getMessage());
        }
        return transactions;
    }

    // READ - Get transactions by type for a user
    public List<Transaction> getTransactionsByType(int userId, TransactionType type) {
        List<Transaction> transactions = new ArrayList<>();
        String sql = "SELECT t.*, u.username, p.transaction_ref " +
                     "FROM transactions t " +
                     "JOIN users u ON t.user_id = u.user_id " +
                     "LEFT JOIN payments p ON t.payment_id = p.payment_id " +
                     "WHERE t.user_id = ? AND t.transaction_type = ? " +
                     "ORDER BY t.transaction_date DESC";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            stmt.setString(2, type.name());
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    transactions.add(mapResultSetToTransaction(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting transactions by type: " + e.getMessage());
        }
        return transactions;
    }

    // READ - Get recent transactions
    public List<Transaction> getRecentTransactions(int userId, int limit) {
        List<Transaction> transactions = new ArrayList<>();
        String sql = "SELECT t.*, u.username, p.transaction_ref " +
                     "FROM transactions t " +
                     "JOIN users u ON t.user_id = u.user_id " +
                     "LEFT JOIN payments p ON t.payment_id = p.payment_id " +
                     "WHERE t.user_id = ? ORDER BY t.transaction_date DESC LIMIT ?";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            stmt.setInt(2, limit);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    transactions.add(mapResultSetToTransaction(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting recent transactions: " + e.getMessage());
        }
        return transactions;
    }

    // UPDATE - Update transaction remarks
    public boolean updateTransactionRemarks(int transactionId, String remarks) {
        String sql = "UPDATE transactions SET description = ? WHERE transaction_id = ?";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, remarks);
            stmt.setInt(2, transactionId);
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating transaction: " + e.getMessage());
        }
        return false;
    }

    // DELETE - Delete transaction
    public boolean deleteTransaction(int transactionId) {
        String sql = "DELETE FROM transactions WHERE transaction_id = ?";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, transactionId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting transaction: " + e.getMessage());
        }
        return false;
    }

    // DELETE - Delete old transactions
    public int deleteOldTransactions(int userId, int daysOld) {
        String sql = "DELETE FROM transactions WHERE user_id = ? AND " +
                     "transaction_date < DATE_SUB(NOW(), INTERVAL ? DAY)";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            stmt.setInt(2, daysOld);
            
            return stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error deleting old transactions: " + e.getMessage());
        }
        return 0;
    }

    // Helper method
    private Transaction mapResultSetToTransaction(ResultSet rs) throws SQLException {
        Transaction transaction = new Transaction();
        transaction.setTransactionId(rs.getInt("transaction_id"));
        transaction.setUserId(rs.getInt("user_id"));
        
        int paymentId = rs.getInt("payment_id");
        transaction.setPaymentId(rs.wasNull() ? null : paymentId);
        
        transaction.setTransactionType(TransactionType.valueOf(rs.getString("transaction_type")));
        transaction.setAmount(rs.getBigDecimal("amount"));
        transaction.setBalanceBefore(rs.getBigDecimal("balance_before"));
        transaction.setBalanceAfter(rs.getBigDecimal("balance_after"));
        transaction.setDescription(rs.getString("description"));
        transaction.setTransactionDate(rs.getTimestamp("transaction_date"));
        transaction.setUsername(rs.getString("username"));
        transaction.setPaymentRef(rs.getString("transaction_ref"));
        return transaction;
    }
}