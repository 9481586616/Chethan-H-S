package com.mugateway.dao;

import com.mugateway.config.DBConfig;
import com.mugateway.model.Bill;
import com.mugateway.model.Bill.BillStatus;
import com.mugateway.util.DateUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BillDAO {

    // CREATE - Generate new bill
    public boolean createBill(Bill bill) {
        String sql = "INSERT INTO bills (user_id, utility_id, bill_number, bill_amount, due_date, bill_status) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, bill.getUserId());
            stmt.setInt(2, bill.getUtilityId());
            stmt.setString(3, bill.getBillNumber());
            stmt.setBigDecimal(4, bill.getBillAmount());
            stmt.setDate(5, bill.getDueDate());
            stmt.setString(6, bill.getBillStatus().name());
            
            int affectedRows = stmt.executeUpdate();
            
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        bill.setBillId(generatedKeys.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error creating bill: " + e.getMessage());
        }
        return false;
    }

    // READ - Get bill by ID
    public Bill getBillById(int billId) {
        String sql = "SELECT b.*, u.username, ut.utility_name " +
                     "FROM bills b " +
                     "JOIN users u ON b.user_id = u.user_id " +
                     "JOIN utilities ut ON b.utility_id = ut.utility_id " +
                     "WHERE b.bill_id = ?";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, billId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToBill(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting bill: " + e.getMessage());
        }
        return null;
    }

    // READ - Get bill by bill number
    public Bill getBillByNumber(String billNumber) {
        String sql = "SELECT b.*, u.username, ut.utility_name " +
                     "FROM bills b " +
                     "JOIN users u ON b.user_id = u.user_id " +
                     "JOIN utilities ut ON b.utility_id = ut.utility_id " +
                     "WHERE b.bill_number = ?";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, billNumber);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToBill(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting bill: " + e.getMessage());
        }
        return null;
    }

    // READ - Get all bills for a user
    public List<Bill> getBillsByUserId(int userId) {
        List<Bill> bills = new ArrayList<>();
        String sql = "SELECT b.*, u.username, ut.utility_name " +
                     "FROM bills b " +
                     "JOIN users u ON b.user_id = u.user_id " +
                     "JOIN utilities ut ON b.utility_id = ut.utility_id " +
                     "WHERE b.user_id = ? ORDER BY b.due_date DESC";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    bills.add(mapResultSetToBill(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting bills: " + e.getMessage());
        }
        return bills;
    }

    // READ - Get unpaid bills for a user
    public List<Bill> getUnpaidBillsByUserId(int userId) {
        List<Bill> bills = new ArrayList<>();
        String sql = "SELECT b.*, u.username, ut.utility_name " +
                     "FROM bills b " +
                     "JOIN users u ON b.user_id = u.user_id " +
                     "JOIN utilities ut ON b.utility_id = ut.utility_id " +
                     "WHERE b.user_id = ? AND b.bill_status IN ('UNPAID', 'OVERDUE') " +
                     "ORDER BY b.due_date ASC";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    bills.add(mapResultSetToBill(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting unpaid bills: " + e.getMessage());
        }
        return bills;
    }

    // READ - Get overdue bills
    public List<Bill> getOverdueBills() {
        List<Bill> bills = new ArrayList<>();
        String sql = "SELECT b.*, u.username, ut.utility_name " +
                     "FROM bills b " +
                     "JOIN users u ON b.user_id = u.user_id " +
                     "JOIN utilities ut ON b.utility_id = ut.utility_id " +
                     "WHERE b.bill_status = 'UNPAID' AND b.due_date < CURDATE()";
        
        try (Connection conn = DBConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                bills.add(mapResultSetToBill(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error getting overdue bills: " + e.getMessage());
        }
        return bills;
    }

    // UPDATE - Update bill status
    public boolean updateBillStatus(int billId, BillStatus status) {
        String sql = "UPDATE bills SET bill_status = ?, paid_date = ? WHERE bill_id = ?";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, status.name());
            stmt.setTimestamp(2, status == BillStatus.PAID ? DateUtil.getCurrentTimestamp() : null);
            stmt.setInt(3, billId);
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating bill status: " + e.getMessage());
        }
        return false;
    }

    // UPDATE - Update bill
    public boolean updateBill(Bill bill) {
        String sql = "UPDATE bills SET utility_id = ?, bill_amount = ?, due_date = ?, " +
                     "bill_status = ? WHERE bill_id = ?";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, bill.getUtilityId());
            stmt.setBigDecimal(2, bill.getBillAmount());
            stmt.setDate(3, bill.getDueDate());
            stmt.setString(4, bill.getBillStatus().name());
            stmt.setInt(5, bill.getBillId());
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating bill: " + e.getMessage());
        }
        return false;
    }

    // UPDATE - Mark overdue bills
    public int markOverdueBills() {
        String sql = "UPDATE bills SET bill_status = 'OVERDUE' " +
                     "WHERE bill_status = 'UNPAID' AND due_date < CURDATE()";
        
        try (Connection conn = DBConfig.getConnection();
             Statement stmt = conn.createStatement()) {
            
            return stmt.executeUpdate(sql);
        } catch (SQLException e) {
            System.err.println("Error marking overdue bills: " + e.getMessage());
        }
        return 0;
    }

    // DELETE - Delete bill
    public boolean deleteBill(int billId) {
        String sql = "DELETE FROM bills WHERE bill_id = ?";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, billId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting bill: " + e.getMessage());
        }
        return false;
    }

    // Generate unique bill number
    public String generateBillNumber(int utilityId) {
        return "BILL" + utilityId + DateUtil.generateTimestampId();
    }

    // Helper method
    private Bill mapResultSetToBill(ResultSet rs) throws SQLException {
        Bill bill = new Bill();
        bill.setBillId(rs.getInt("bill_id"));
        bill.setUserId(rs.getInt("user_id"));
        bill.setUtilityId(rs.getInt("utility_id"));
        bill.setBillNumber(rs.getString("bill_number"));
        bill.setBillAmount(rs.getBigDecimal("bill_amount"));
        bill.setDueDate(rs.getDate("due_date"));
        bill.setBillStatus(BillStatus.valueOf(rs.getString("bill_status")));
        bill.setGeneratedDate(rs.getTimestamp("generated_date"));
        bill.setPaidDate(rs.getTimestamp("paid_date"));
        bill.setUsername(rs.getString("username"));
        bill.setUtilityName(rs.getString("utility_name"));
        return bill;
    }
}