package com.mugateway.dao;

import com.mugateway.config.DBConfig;
import com.mugateway.model.Payment;
import com.mugateway.model.Payment.PaymentMode;
import com.mugateway.model.Payment.PaymentStatus;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PaymentDAO {

    // CREATE - Create new payment
    public boolean createPayment(Payment payment) {
        String sql = "INSERT INTO payments (user_id, bill_id, payment_amount, payment_mode, " +
                     "payment_status, transaction_ref, is_offline, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, payment.getUserId());
            if (payment.getBillId() != null) {
                stmt.setInt(2, payment.getBillId());
            } else {
                stmt.setNull(2, Types.INTEGER);
            }
            stmt.setBigDecimal(3, payment.getPaymentAmount());
            stmt.setString(4, payment.getPaymentMode().name());
            stmt.setString(5, payment.getPaymentStatus().name());
            stmt.setString(6, payment.getTransactionRef());
            stmt.setBoolean(7, payment.isOffline());
            stmt.setString(8, payment.getRemarks());
            
            int affectedRows = stmt.executeUpdate();
            
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        payment.setPaymentId(generatedKeys.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error creating payment: " + e.getMessage());
        }
        return false;
    }

    // READ - Get payment by ID
    public Payment getPaymentById(int paymentId) {
        String sql = "SELECT p.*, u.username, b.bill_number " +
                     "FROM payments p " +
                     "JOIN users u ON p.user_id = u.user_id " +
                     "LEFT JOIN bills b ON p.bill_id = b.bill_id " +
                     "WHERE p.payment_id = ?";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, paymentId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToPayment(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting payment: " + e.getMessage());
        }
        return null;
    }

    // READ - Get payment by transaction reference
    public Payment getPaymentByTransactionRef(String transactionRef) {
        String sql = "SELECT p.*, u.username, b.bill_number " +
                     "FROM payments p " +
                     "JOIN users u ON p.user_id = u.user_id " +
                     "LEFT JOIN bills b ON p.bill_id = b.bill_id " +
                     "WHERE p.transaction_ref = ?";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, transactionRef);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToPayment(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting payment: " + e.getMessage());
        }
        return null;
    }

    // READ - Get all payments for a user
    public List<Payment> getPaymentsByUserId(int userId) {
        List<Payment> payments = new ArrayList<>();
        String sql = "SELECT p.*, u.username, b.bill_number " +
                     "FROM payments p " +
                     "JOIN users u ON p.user_id = u.user_id " +
                     "LEFT JOIN bills b ON p.bill_id = b.bill_id " +
                     "WHERE p.user_id = ? ORDER BY p.payment_date DESC";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    payments.add(mapResultSetToPayment(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting payments: " + e.getMessage());
        }
        return payments;
    }

    // READ - Get successful payments for a user
    public List<Payment> getSuccessfulPaymentsByUserId(int userId) {
        List<Payment> payments = new ArrayList<>();
        String sql = "SELECT p.*, u.username, b.bill_number " +
                     "FROM payments p " +
                     "JOIN users u ON p.user_id = u.user_id " +
                     "LEFT JOIN bills b ON p.bill_id = b.bill_id " +
                     "WHERE p.user_id = ? AND p.payment_status = 'SUCCESS' " +
                     "ORDER BY p.payment_date DESC";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    payments.add(mapResultSetToPayment(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting successful payments: " + e.getMessage());
        }
        return payments;
    }

    // UPDATE - Update payment status
    public boolean updatePaymentStatus(int paymentId, PaymentStatus status) {
        String sql = "UPDATE payments SET payment_status = ? WHERE payment_id = ?";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, status.name());
            stmt.setInt(2, paymentId);
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating payment status: " + e.getMessage());
        }
        return false;
    }

    // UPDATE - Update payment
    public boolean updatePayment(Payment payment) {
        String sql = "UPDATE payments SET payment_mode = ?, payment_status = ?, " +
                     "remarks = ? WHERE payment_id = ?";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, payment.getPaymentMode().name());
            stmt.setString(2, payment.getPaymentStatus().name());
            stmt.setString(3, payment.getRemarks());
            stmt.setInt(4, payment.getPaymentId());
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating payment: " + e.getMessage());
        }
        return false;
    }

    // DELETE - Delete payment
    public boolean deletePayment(int paymentId) {
        String sql = "DELETE FROM payments WHERE payment_id = ?";
        
        try (Connection conn = DBConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, paymentId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting payment: " + e.getMessage());
        }
        return false;
    }

    // Helper method
    private Payment mapResultSetToPayment(ResultSet rs) throws SQLException {
        Payment payment = new Payment();
        payment.setPaymentId(rs.getInt("payment_id"));
        payment.setUserId(rs.getInt("user_id"));
        
        int billId = rs.getInt("bill_id");
        payment.setBillId(rs.wasNull() ? null : billId);
        
        payment.setPaymentAmount(rs.getBigDecimal("payment_amount"));
        payment.setPaymentMode(PaymentMode.valueOf(rs.getString("payment_mode")));
        payment.setPaymentStatus(PaymentStatus.valueOf(rs.getString("payment_status")));
        payment.setTransactionRef(rs.getString("transaction_ref"));
        payment.setOffline(rs.getBoolean("is_offline"));
        payment.setPaymentDate(rs.getTimestamp("payment_date"));
        payment.setRemarks(rs.getString("remarks"));
        payment.setUsername(rs.getString("username"));
        payment.setBillNumber(rs.getString("bill_number"));
        return payment;
    }
}