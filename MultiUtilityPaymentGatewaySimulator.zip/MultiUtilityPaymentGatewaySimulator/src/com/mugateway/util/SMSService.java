package com.mugateway.util;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

public class SMSService {
    // Twilio credentials - Replace with your actual credentials
    private static final String ACCOUNT_SID = "AC5ce6eb2e9ffca4e18796a1d5cdc69ac4";
    private static final String AUTH_TOKEN = "e624cae3ed53dc8130f04ecO301d3ce5";
    private static final String FROM_PHONE = "+919481586616"; // Your Twilio phone number
    
    private static boolean isInitialized = false;
    private static boolean simulationMode = true; // Set to false when using real Twilio

    static {
        try {
            if (!simulationMode) {
                Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
                isInitialized = true;
                System.out.println("📱 Twilio SMS Service initialized successfully!");
            }
        } catch (Exception e) {
            System.err.println("⚠️ SMS Service running in simulation mode: " + e.getMessage());
            simulationMode = true;
        }
    }

    public static boolean sendSMS(String toPhone, String messageBody) {
        if (simulationMode) {
            return simulateSMS(toPhone, messageBody);
        }
        
        try {
            // Format phone number if needed (add country code)
            String formattedPhone = formatPhoneNumber(toPhone);
            
            Message message = Message.creator(
                new PhoneNumber(formattedPhone),
                new PhoneNumber(FROM_PHONE),
                messageBody
            ).create();

            System.out.println("📱 SMS sent successfully! SID: " + message.getSid());
            return true;
        } catch (Exception e) {
            System.err.println("❌ Failed to send SMS: " + e.getMessage());
            return false;
        }
    }

    private static boolean simulateSMS(String toPhone, String messageBody) {
        System.out.println("\n╔══════════════════════════════════════════════════════════════╗");
        System.out.println("║                    📱 SMS NOTIFICATION                       ║");
        System.out.println("╠══════════════════════════════════════════════════════════════╣");
        System.out.println("║ To: " + String.format("%-57s", toPhone) + "║");
        System.out.println("╠══════════════════════════════════════════════════════════════╣");
        
        // Word wrap message
        String[] words = messageBody.split(" ");
        StringBuilder line = new StringBuilder("║ ");
        for (String word : words) {
            if (line.length() + word.length() > 60) {
                System.out.println(String.format("%-63s║", line.toString()));
                line = new StringBuilder("║ ");
            }
            line.append(word).append(" ");
        }
        if (line.length() > 2) {
            System.out.println(String.format("%-63s║", line.toString()));
        }
        
        System.out.println("╠══════════════════════════════════════════════════════════════╣");
        System.out.println("║ Status: ✅ DELIVERED (Simulation Mode)                       ║");
        System.out.println("╚══════════════════════════════════════════════════════════════╝\n");
        return true;
    }

    private static String formatPhoneNumber(String phone) {
        // Remove all non-digit characters
        String digits = phone.replaceAll("[^0-9]", "");
        
        // Add country code if not present (assuming India +91)
        if (digits.length() == 10) {
            return "+91" + digits;
        } else if (!digits.startsWith("+")) {
            return "+" + digits;
        }
        return phone;
    }

    // Predefined SMS templates
    public static boolean sendRegistrationSMS(String phone, String username) {
        String message = "Welcome to MU Gateway, " + username + "! " +
                        "Your registration is successful. Start managing your utility bills now!";
        return sendSMS(phone, message);
    }

    public static boolean sendLoginAlertSMS(String phone, String username) {
        String message = "MU Gateway Alert: Login detected for user " + username + 
                        " at " + DateUtil.formatDateTime(DateUtil.getCurrentTimestamp()) + 
                        ". If this wasn't you, secure your account immediately!";
        return sendSMS(phone, message);
    }

    public static boolean sendPaymentSuccessSMS(String phone, String transactionRef, 
                                                 String amount, String paymentMode) {
        String message = "MU Gateway: Payment of Rs." + amount + " via " + paymentMode + 
                        " successful! Transaction ID: " + transactionRef + 
                        ". Thank you for using our service!";
        return sendSMS(phone, message);
    }

    public static boolean sendBillReminderSMS(String phone, String billNumber, 
                                               String amount, String dueDate) {
        String message = "MU Gateway Reminder: Bill " + billNumber + 
                        " of Rs." + amount + " is due on " + dueDate + 
                        ". Pay now to avoid late charges!";
        return sendSMS(phone, message);
    }

    public static boolean sendOTPSMS(String phone, String otp) {
        String message = "Your MU Gateway OTP is: " + otp + 
                        ". Valid for 5 minutes. Do not share with anyone.";
        return sendSMS(phone, message);
    }

    public static void setSimulationMode(boolean mode) {
        simulationMode = mode;
    }

    public static boolean isSimulationMode() {
        return simulationMode;
    }
}