package com.mugateway.util;

import com.mugateway.model.Payment.PaymentMode;
import com.mugateway.model.Payment.PaymentStatus;
import java.math.BigDecimal;
import java.util.Random;
import java.util.Scanner;

public class PaymentGateway {
    private static final Random random = new Random();
    private static boolean simulationMode = true;
    
    // Simulated payment success rate (90%)
    private static final double SUCCESS_RATE = 0.90;

    public static class PaymentResult {
        private boolean success;
        private String transactionRef;
        private PaymentStatus status;
        private String message;

        public PaymentResult(boolean success, String transactionRef, PaymentStatus status, String message) {
            this.success = success;
            this.transactionRef = transactionRef;
            this.status = status;
            this.message = message;
        }

        public boolean isSuccess() { return success; }
        public String getTransactionRef() { return transactionRef; }
        public PaymentStatus getStatus() { return status; }
        public String getMessage() { return message; }
    }

    public static PaymentResult processPayment(PaymentMode paymentMode, BigDecimal amount, 
                                                Scanner scanner) {
        String transactionRef = DateUtil.generateTransactionRef("TXN");
        
        System.out.println("\n╔════════════════════════════════════════════════════════╗");
        System.out.println("║              💳 PAYMENT GATEWAY                        ║");
        System.out.println("╠════════════════════════════════════════════════════════╣");
        System.out.printf("║ Amount: ₹%-45.2f ║%n", amount);
        System.out.printf("║ Mode: %-48s ║%n", paymentMode);
        System.out.printf("║ Transaction Ref: %-37s ║%n", transactionRef);
        System.out.println("╚════════════════════════════════════════════════════════╝");

        switch (paymentMode) {
            case UPI:
                return processUPIPayment(amount, transactionRef, scanner);
            case CREDIT_CARD:
            case DEBIT_CARD:
                return processCardPayment(paymentMode, amount, transactionRef, scanner);
            case NET_BANKING:
                return processNetBanking(amount, transactionRef, scanner);
            case WALLET:
                return processWalletPayment(amount, transactionRef);
            case CASH:
                return processCashPayment(amount, transactionRef, scanner);
            default:
                return new PaymentResult(false, transactionRef, PaymentStatus.FAILED, 
                                        "Invalid payment mode");
        }
    }

    private static PaymentResult processUPIPayment(BigDecimal amount, String transactionRef, 
                                                    Scanner scanner) {
        System.out.println("\n═══════════════ UPI PAYMENT ═══════════════");
        System.out.print("Enter UPI ID (e.g., user@upi): ");
        String upiId = scanner.nextLine().trim();

        if (!isValidUPI(upiId)) {
            return new PaymentResult(false, transactionRef, PaymentStatus.FAILED, 
                                    "Invalid UPI ID format");
        }

        System.out.print("Enter UPI PIN: ");
        String pin = scanner.nextLine().trim();

        return simulatePaymentProcessing(transactionRef, "UPI payment via " + upiId);
    }

    private static PaymentResult processCardPayment(PaymentMode mode, BigDecimal amount, 
                                                     String transactionRef, Scanner scanner) {
        String cardType = mode == PaymentMode.CREDIT_CARD ? "CREDIT CARD" : "DEBIT CARD";
        System.out.println("\n═══════════════ " + cardType + " PAYMENT ═══════════════");
        
        System.out.print("Enter Card Number (16 digits): ");
        String cardNumber = scanner.nextLine().trim().replaceAll("\\s", "");
        
        if (!isValidCardNumber(cardNumber)) {
            return new PaymentResult(false, transactionRef, PaymentStatus.FAILED, 
                                    "Invalid card number");
        }

        System.out.print("Enter Expiry (MM/YY): ");
        String expiry = scanner.nextLine().trim();
        
        if (!isValidExpiry(expiry)) {
            return new PaymentResult(false, transactionRef, PaymentStatus.FAILED, 
                                    "Invalid expiry date");
        }

        System.out.print("Enter CVV (3 digits): ");
        String cvv = scanner.nextLine().trim();
        
        if (!isValidCVV(cvv)) {
            return new PaymentResult(false, transactionRef, PaymentStatus.FAILED, 
                                    "Invalid CVV");
        }

        System.out.print("Enter OTP sent to registered mobile: ");
        String otp = scanner.nextLine().trim();

        String maskedCard = "**** **** **** " + cardNumber.substring(12);
        return simulatePaymentProcessing(transactionRef, cardType + " ending " + maskedCard);
    }

    private static PaymentResult processNetBanking(BigDecimal amount, String transactionRef, 
                                                    Scanner scanner) {
        System.out.println("\n═══════════════ NET BANKING ═══════════════");
        System.out.println("Select Bank:");
        System.out.println("1. State Bank of India");
        System.out.println("2. HDFC Bank");
        System.out.println("3. ICICI Bank");
        System.out.println("4. Axis Bank");
        System.out.println("5. Kotak Mahindra Bank");
        System.out.println("6. Other Bank");
        System.out.print("Choose bank (1-6): ");
        
        int bankChoice = 0;
        try {
            bankChoice = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            return new PaymentResult(false, transactionRef, PaymentStatus.FAILED, 
                                    "Invalid bank selection");
        }

        String[] banks = {"", "SBI", "HDFC", "ICICI", "AXIS", "KOTAK", "OTHER"};
        if (bankChoice < 1 || bankChoice > 6) {
            return new PaymentResult(false, transactionRef, PaymentStatus.FAILED, 
                                    "Invalid bank selection");
        }

        System.out.print("Enter Customer ID: ");
        String customerId = scanner.nextLine().trim();
        
        System.out.print("Enter Password: ");
        String password = scanner.nextLine().trim();

        System.out.print("Enter Transaction Password/OTP: ");
        String txnPassword = scanner.nextLine().trim();

        return simulatePaymentProcessing(transactionRef, "Net Banking via " + banks[bankChoice]);
    }

    private static PaymentResult processWalletPayment(BigDecimal amount, String transactionRef) {
        System.out.println("\n═══════════════ WALLET PAYMENT ═══════════════");
        System.out.println("Processing wallet payment...");
        // Wallet balance check is done in PaymentService
        return simulatePaymentProcessing(transactionRef, "Wallet Payment");
    }

    private static PaymentResult processCashPayment(BigDecimal amount, String transactionRef, 
                                                     Scanner scanner) {
        System.out.println("\n═══════════════ CASH PAYMENT ═══════════════");
        System.out.println("Amount to pay: ₹" + amount);
        System.out.print("Confirm cash received? (yes/no): ");
        String confirm = scanner.nextLine().trim().toLowerCase();

        if (confirm.equals("yes") || confirm.equals("y")) {
            return new PaymentResult(true, transactionRef, PaymentStatus.SUCCESS, 
                                    "Cash payment confirmed");
        }
        return new PaymentResult(false, transactionRef, PaymentStatus.FAILED, 
                                "Cash payment not confirmed");
    }

    private static PaymentResult simulatePaymentProcessing(String transactionRef, String method) {
        System.out.println("\n⏳ Processing payment...");
        
        // Simulate processing delay
        try {
            for (int i = 0; i < 3; i++) {
                Thread.sleep(500);
                System.out.print(".");
            }
            System.out.println();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        // Simulate success/failure based on success rate
        boolean success = random.nextDouble() < SUCCESS_RATE;
        
        if (success) {
            System.out.println("\n✅ PAYMENT SUCCESSFUL!");
            System.out.println("Transaction Reference: " + transactionRef);
            return new PaymentResult(true, transactionRef, PaymentStatus.SUCCESS, 
                                    method + " - Payment processed successfully");
        } else {
            System.out.println("\n❌ PAYMENT FAILED!");
            System.out.println("Please try again or use a different payment method.");
            return new PaymentResult(false, transactionRef, PaymentStatus.FAILED, 
                                    method + " - Payment failed, please retry");
        }
    }

    // Validation methods
    private static boolean isValidUPI(String upi) {
        return upi != null && upi.matches("^[a-zA-Z0-9.\\-_]{2,256}@[a-zA-Z]{2,64}$");
    }

    private static boolean isValidCardNumber(String cardNumber) {
        return cardNumber != null && cardNumber.matches("^[0-9]{16}$");
    }

    private static boolean isValidExpiry(String expiry) {
        return expiry != null && expiry.matches("^(0[1-9]|1[0-2])/([0-9]{2})$");
    }

    private static boolean isValidCVV(String cvv) {
        return cvv != null && cvv.matches("^[0-9]{3,4}$");
    }

    public static void setSimulationMode(boolean mode) {
        simulationMode = mode;
    }
}