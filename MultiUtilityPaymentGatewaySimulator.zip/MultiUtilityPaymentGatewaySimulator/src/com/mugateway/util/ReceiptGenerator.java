package com.mugateway.util;

import com.mugateway.model.*;
import java.io.*;
import java.math.BigDecimal;

public class ReceiptGenerator {
    private static final String RECEIPTS_DIR = "receipts/";

    static {
        // Create receipts directory if it doesn't exist
        File dir = new File(RECEIPTS_DIR);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }

    public static String generatePaymentReceipt(Payment payment, User user, Bill bill) {
        StringBuilder receipt = new StringBuilder();
        String line = "═".repeat(60);
        
        receipt.append("\n").append(line).append("\n");
        receipt.append("║" + centerText("PAYMENT RECEIPT", 58) + "║\n");
        receipt.append("║" + centerText("MU GATEWAY", 58) + "║\n");
        receipt.append(line).append("\n\n");
        
        receipt.append(String.format("%-20s: %s%n", "Receipt Date", 
            DateUtil.formatDateTime(DateUtil.getCurrentTimestamp())));
        receipt.append(String.format("%-20s: %s%n", "Transaction ID", 
            payment.getTransactionRef()));
        receipt.append(String.format("%-20s: %s%n", "Payment ID", 
            payment.getPaymentId()));
        
        receipt.append("\n--- Customer Details ---\n");
        receipt.append(String.format("%-20s: %s%n", "Name", user.getFullName()));
        receipt.append(String.format("%-20s: %s%n", "Username", user.getUsername()));
        receipt.append(String.format("%-20s: %s%n", "Email", user.getEmail()));
        receipt.append(String.format("%-20s: %s%n", "Phone", user.getPhone()));
        
        if (bill != null) {
            receipt.append("\n--- Bill Details ---\n");
            receipt.append(String.format("%-20s: %s%n", "Bill Number", bill.getBillNumber()));
            receipt.append(String.format("%-20s: %s%n", "Utility", bill.getUtilityName()));
            receipt.append(String.format("%-20s: %s%n", "Due Date", 
                DateUtil.formatDate(bill.getDueDate())));
        }
        
        receipt.append("\n--- Payment Details ---\n");
        receipt.append(String.format("%-20s: ₹%.2f%n", "Amount Paid", 
            payment.getPaymentAmount()));
        receipt.append(String.format("%-20s: %s%n", "Payment Mode", 
            payment.getPaymentMode()));
        receipt.append(String.format("%-20s: %s%n", "Payment Status", 
            payment.getPaymentStatus()));
        receipt.append(String.format("%-20s: %s%n", "Payment Date", 
            DateUtil.formatDateTime(payment.getPaymentDate())));
        
        if (payment.isOffline()) {
            receipt.append(String.format("%-20s: %s%n", "Payment Type", "OFFLINE"));
        }
        
        receipt.append("\n").append(line).append("\n");
        receipt.append(centerText("Thank you for using MU Gateway!", 60)).append("\n");
        receipt.append(centerText("For support: support@mugateway.com", 60)).append("\n");
        receipt.append(line).append("\n");
        
        String receiptContent = receipt.toString();
        
        // Print to console
        System.out.println(receiptContent);
        
        // Save to file
        saveReceiptToFile(payment.getTransactionRef(), receiptContent);
        
        return receiptContent;
    }

    public static String generateBillReceipt(Bill bill, User user, Utility utility) {
        StringBuilder receipt = new StringBuilder();
        String line = "═".repeat(60);
        
        receipt.append("\n").append(line).append("\n");
        receipt.append("║" + centerText("UTILITY BILL", 58) + "║\n");
        receipt.append("║" + centerText("MU GATEWAY", 58) + "║\n");
        receipt.append(line).append("\n\n");
        
        receipt.append("--- Bill Information ---\n");
        receipt.append(String.format("%-20s: %s%n", "Bill Number", bill.getBillNumber()));
        receipt.append(String.format("%-20s: %s%n", "Generated Date", 
            DateUtil.formatDateTime(bill.getGeneratedDate())));
        receipt.append(String.format("%-20s: %s%n", "Status", bill.getBillStatus()));
        
        receipt.append("\n--- Customer Details ---\n");
        receipt.append(String.format("%-20s: %s%n", "Name", user.getFullName()));
        receipt.append(String.format("%-20s: %s%n", "Account", user.getUsername()));
        
        receipt.append("\n--- Utility Details ---\n");
        receipt.append(String.format("%-20s: %s%n", "Utility", utility.getUtilityName()));
        receipt.append(String.format("%-20s: %s%n", "Provider", utility.getProviderName()));
        receipt.append(String.format("%-20s: %s%n", "Type", utility.getUtilityType()));
        
        receipt.append("\n--- Amount Details ---\n");
        receipt.append(String.format("%-20s: ₹%.2f%n", "Bill Amount", bill.getBillAmount()));
        receipt.append(String.format("%-20s: %s%n", "Due Date", 
            DateUtil.formatDate(bill.getDueDate())));
        
        receipt.append("\n").append(line).append("\n");
        receipt.append(centerText("Pay before due date to avoid late charges", 60)).append("\n");
        receipt.append(line).append("\n");
        
        return receipt.toString();
    }

    public static String generateTransactionStatement(User user, 
            java.util.List<Transaction> transactions) {
        StringBuilder statement = new StringBuilder();
        String line = "═".repeat(100);
        
        statement.append("\n").append(line).append("\n");
        statement.append(centerText("TRANSACTION STATEMENT", 100)).append("\n");
        statement.append(centerText("MU GATEWAY", 100)).append("\n");
        statement.append(line).append("\n\n");
        
        statement.append(String.format("%-20s: %s%n", "Account Holder", user.getFullName()));
        statement.append(String.format("%-20s: %s%n", "Username", user.getUsername()));
        statement.append(String.format("%-20s: ₹%.2f%n", "Current Balance", user.getWalletBalance()));
        statement.append(String.format("%-20s: %s%n", "Statement Date", 
            DateUtil.formatDateTime(DateUtil.getCurrentTimestamp())));
        
        statement.append("\n").append("-".repeat(100)).append("\n");
        statement.append(String.format("%-8s %-15s %-15s %-15s %-20s %-20s%n",
            "ID", "Type", "Amount", "Balance", "Description", "Date"));
        statement.append("-".repeat(100)).append("\n");
        
        for (Transaction txn : transactions) {
            statement.append(String.format("%-8d %-15s ₹%-14.2f ₹%-14.2f %-20s %-20s%n",
                txn.getTransactionId(),
                txn.getTransactionType(),
                txn.getAmount(),
                txn.getBalanceAfter() != null ? txn.getBalanceAfter() : BigDecimal.ZERO,
                truncate(txn.getDescription(), 18),
                DateUtil.formatDateTime(txn.getTransactionDate())
            ));
        }
        
        statement.append("-".repeat(100)).append("\n");
        statement.append(String.format("Total Transactions: %d%n", transactions.size()));
        statement.append(line).append("\n");
        
        return statement.toString();
    }

    private static void saveReceiptToFile(String transactionRef, String content) {
        String filename = RECEIPTS_DIR + "receipt_" + transactionRef + ".txt";
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            writer.print(content);
            System.out.println("📄 Receipt saved to: " + filename);
        } catch (IOException e) {
            System.err.println("Failed to save receipt: " + e.getMessage());
        }
    }

    private static String centerText(String text, int width) {
        int padding = (width - text.length()) / 2;
        return " ".repeat(Math.max(0, padding)) + text + 
               " ".repeat(Math.max(0, width - text.length() - padding));
    }

    private static String truncate(String text, int maxLength) {
        if (text == null) return "";
        return text.length() > maxLength ? text.substring(0, maxLength - 3) + "..." : text;
    }
}