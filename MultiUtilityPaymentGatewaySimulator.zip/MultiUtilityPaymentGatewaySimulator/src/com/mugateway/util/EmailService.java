package com.mugateway.util;

import jakarta.mail.*;
import jakarta.mail.internet.*;
import jakarta.activation.*;
import java.util.Properties;

public class EmailService {
    // Email configuration - Replace with your actual credentials
    private static final String SMTP_HOST = "smtp.gmail.com";
    private static final String SMTP_PORT = "587";
    private static final String EMAIL_FROM = "chethanhs9481@gmail.com";
    private static final String EMAIL_PASSWORD = "gstz fdhs ghmj prse"; // Use App Password for Gmail
    
    private static boolean simulationMode = true; // Set to false when using real SMTP
    private static Session session;

    static {
        try {
            if (!simulationMode) {
                Properties props = new Properties();
                props.put("mail.smtp.auth", "true");
                props.put("mail.smtp.starttls.enable", "true");
                props.put("mail.smtp.host", SMTP_HOST);
                props.put("mail.smtp.port", SMTP_PORT);
                props.put("mail.smtp.ssl.trust", SMTP_HOST);

                session = Session.getInstance(props, new Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(EMAIL_FROM, EMAIL_PASSWORD);
                    }
                });
                System.out.println("📧 Email Service initialized successfully!");
            }
        } catch (Exception e) {
            System.err.println("⚠️ Email Service running in simulation mode: " + e.getMessage());
            simulationMode = true;
        }
    }

    public static boolean sendEmail(String toEmail, String subject, String body) {
        if (simulationMode) {
            return simulateEmail(toEmail, subject, body);
        }

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(EMAIL_FROM));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
            message.setSubject(subject);
            message.setContent(body, "text/html; charset=utf-8");

            Transport.send(message);
            System.out.println("📧 Email sent successfully to: " + toEmail);
            return true;
        } catch (MessagingException e) {
            System.err.println("❌ Failed to send email: " + e.getMessage());
            return false;
        }
    }

    private static boolean simulateEmail(String toEmail, String subject, String body) {
        System.out.println("\n╔══════════════════════════════════════════════════════════════════════════╗");
        System.out.println("║                           📧 EMAIL NOTIFICATION                          ║");
        System.out.println("╠══════════════════════════════════════════════════════════════════════════╣");
        System.out.println("║ To: " + String.format("%-71s", toEmail) + "║");
        System.out.println("║ Subject: " + String.format("%-66s", subject) + "║");
        System.out.println("╠══════════════════════════════════════════════════════════════════════════╣");
        
        // Strip HTML and display plain text
        String plainText = body.replaceAll("<[^>]*>", "").replaceAll("&nbsp;", " ");
        String[] lines = plainText.split("\n");
        for (String line : lines) {
            if (line.trim().length() > 0) {
                while (line.length() > 72) {
                    System.out.println("║ " + String.format("%-74s", line.substring(0, 72)) + "║");
                    line = line.substring(72);
                }
                System.out.println("║ " + String.format("%-74s", line) + "║");
            }
        }
        
        System.out.println("╠══════════════════════════════════════════════════════════════════════════╣");
        System.out.println("║ Status: ✅ DELIVERED (Simulation Mode)                                   ║");
        System.out.println("╚══════════════════════════════════════════════════════════════════════════╝\n");
        return true;
    }

    // Email Templates
    public static boolean sendWelcomeEmail(String toEmail, String username, String fullName) {
        String subject = "Welcome to MU Gateway - Registration Successful!";
        String body = buildHtmlTemplate(
            "Welcome to MU Gateway!",
            "Dear " + fullName + ",<br><br>" +
            "Congratulations! Your registration is successful.<br><br>" +
            "<strong>Username:</strong> " + username + "<br><br>" +
            "You can now:<br>" +
            "✓ Pay utility bills<br>" +
            "✓ Recharge mobile & DTH<br>" +
            "✓ Transfer money<br>" +
            "✓ Track all transactions<br><br>" +
            "Thank you for choosing MU Gateway!",
            "Start Managing Bills"
        );
        return sendEmail(toEmail, subject, body);
    }

    public static boolean sendLoginAlertEmail(String toEmail, String username) {
        String subject = "MU Gateway - Login Alert";
        String body = buildHtmlTemplate(
            "Login Alert",
            "Dear User,<br><br>" +
            "A login was detected on your MU Gateway account.<br><br>" +
            "<strong>Username:</strong> " + username + "<br>" +
            "<strong>Time:</strong> " + DateUtil.formatDateTime(DateUtil.getCurrentTimestamp()) + "<br><br>" +
            "If this wasn't you, please secure your account immediately!",
            "Secure Account"
        );
        return sendEmail(toEmail, subject, body);
    }

    public static boolean sendPaymentSuccessEmail(String toEmail, String username,
                                                   String transactionRef, String amount,
                                                   String paymentMode, String billNumber) {
        String subject = "MU Gateway - Payment Successful";
        String body = buildHtmlTemplate(
            "Payment Successful!",
            "Dear " + username + ",<br><br>" +
            "Your payment has been processed successfully.<br><br>" +
            "<table style='border-collapse: collapse;'>" +
            "<tr><td style='padding: 5px;'><strong>Transaction ID:</strong></td><td>" + transactionRef + "</td></tr>" +
            "<tr><td style='padding: 5px;'><strong>Amount:</strong></td><td>₹" + amount + "</td></tr>" +
            "<tr><td style='padding: 5px;'><strong>Payment Mode:</strong></td><td>" + paymentMode + "</td></tr>" +
            (billNumber != null ? "<tr><td style='padding: 5px;'><strong>Bill Number:</strong></td><td>" + billNumber + "</td></tr>" : "") +
            "<tr><td style='padding: 5px;'><strong>Date:</strong></td><td>" + DateUtil.formatDateTime(DateUtil.getCurrentTimestamp()) + "</td></tr>" +
            "</table><br>" +
            "Thank you for using MU Gateway!",
            "View Transaction"
        );
        return sendEmail(toEmail, subject, body);
    }

    public static boolean sendBillReminderEmail(String toEmail, String username,
                                                 String billNumber, String utilityName,
                                                 String amount, String dueDate) {
        String subject = "MU Gateway - Bill Payment Reminder";
        String body = buildHtmlTemplate(
            "Bill Payment Reminder",
            "Dear " + username + ",<br><br>" +
            "This is a reminder that your bill is due soon.<br><br>" +
            "<table style='border-collapse: collapse;'>" +
            "<tr><td style='padding: 5px;'><strong>Bill Number:</strong></td><td>" + billNumber + "</td></tr>" +
            "<tr><td style='padding: 5px;'><strong>Utility:</strong></td><td>" + utilityName + "</td></tr>" +
            "<tr><td style='padding: 5px;'><strong>Amount:</strong></td><td>₹" + amount + "</td></tr>" +
            "<tr><td style='padding: 5px;'><strong>Due Date:</strong></td><td>" + dueDate + "</td></tr>" +
            "</table><br>" +
            "Please pay before the due date to avoid late charges.",
            "Pay Now"
        );
        return sendEmail(toEmail, subject, body);
    }

    private static String buildHtmlTemplate(String title, String content, String buttonText) {
        return "<!DOCTYPE html>" +
               "<html><head><style>" +
               "body{font-family:Arial,sans-serif;background:#f4f4f4;margin:0;padding:20px;}" +
               ".container{max-width:600px;margin:0 auto;background:#fff;border-radius:10px;overflow:hidden;box-shadow:0 2px 10px rgba(0,0,0,0.1);}" +
               ".header{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:#fff;padding:30px;text-align:center;}" +
               ".content{padding:30px;line-height:1.6;color:#333;}" +
               ".button{display:inline-block;background:#667eea;color:#fff;padding:12px 30px;text-decoration:none;border-radius:5px;margin-top:20px;}" +
               ".footer{background:#f8f9fa;padding:20px;text-align:center;color:#666;font-size:12px;}" +
               "</style></head><body>" +
               "<div class='container'>" +
               "<div class='header'><h1>🏦 MU Gateway</h1><h2>" + title + "</h2></div>" +
               "<div class='content'>" + content + "<br><a href='#' class='button'>" + buttonText + "</a></div>" +
               "<div class='footer'>© 2024 MU Gateway. All rights reserved.<br>This is an automated message.</div>" +
               "</div></body></html>";
    }

    public static void setSimulationMode(boolean mode) {
        simulationMode = mode;
    }

    public static boolean isSimulationMode() {
        return simulationMode;
    }
}