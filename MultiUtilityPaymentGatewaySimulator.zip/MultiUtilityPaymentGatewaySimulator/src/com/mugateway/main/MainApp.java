package com.mugateway.main;

import com.mugateway.config.DBConfig;
import com.mugateway.chatbot.ChatbotEngine;
import com.mugateway.dao.*;
import com.mugateway.model.*;
import com.mugateway.model.Bill.BillStatus;
import com.mugateway.model.Payment.PaymentMode;
import com.mugateway.model.Utility.UtilityType;
import com.mugateway.service.*;
import com.mugateway.util.*;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.*;

public class MainApp {
    private final Scanner scanner;
    private final LoginService loginService;
    private final UserService userService;
    private final UtilityService utilityService;
    private final BillService billService;
    private final PaymentService paymentService;
    private final TransactionService transactionService;
    private final ChatbotEngine chatbot;
    
    private boolean running = true;

    public MainApp() {
        this.scanner = new Scanner(System.in);
        this.loginService = new LoginService();
        this.userService = new UserService();
        this.utilityService = new UtilityService();
        this.billService = new BillService();
        this.paymentService = new PaymentService();
        this.transactionService = new TransactionService();
        this.chatbot = new ChatbotEngine();
    }

    public static void main(String[] args) {
        System.out.println("╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║      🌐 WELCOME TO MU GATEWAY - MULTI UTILITY PAYMENTS       ║");
        System.out.println("║              Seamless Bills & Payments Management             ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");
        
        // Test database connection
        if (!DBConfig.testConnection()) {
            System.out.println("\n❌ DATABASE CONNECTION FAILED!");
            System.out.println("Please ensure MySQL is running and credentials are correct.");
            System.exit(1);
        }
        
        MainApp app = new MainApp();
        app.run();
    }

    public void run() {
        showWelcomeMenu();
        
        while (running) {
            try {
                if (loginService.isLoggedIn()) {
                    showMainMenu();
                } else {
                    showAuthenticationMenu();
                }
            } catch (Exception e) {
                System.err.println("❌ An error occurred: " + e.getMessage());
                e.printStackTrace();
            }
        }
        
        closeApplication();
    }

    private void showWelcomeMenu() {
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║                    🏠 WELCOME TO MU GATEWAY                   ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");
        System.out.println("\nFeatures:");
        System.out.println("✓ User Registration & Login (Secure Password Encryption)");
        System.out.println("✓ Manage Utilities (Electricity, Water, Gas, Mobile, Internet, DTH)");
        System.out.println("✓ Bill Generation & Management");
        System.out.println("✓ Multiple Payment Options (UPI, Cards, Net Banking, Wallet, Cash)");
        System.out.println("✓ Transaction History & Mini Statements");
        System.out.println("✓ Real-time SMS & Email Notifications");
        System.out.println("✓ Intelligent Chatbot Assistant");
        System.out.println("✓ Complete CRUD Operations");
        System.out.println("\n");
    }

    private void showAuthenticationMenu() {
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║                   🔐 AUTHENTICATION MENU                      ║");
        System.out.println("╠════════════════════════════════════════════════════════════════╣");
        System.out.println("║ 1. Login                                                       ║");
        System.out.println("║ 2. Register                                                    ║");
        System.out.println("║ 3. Admin Panel (View Utilities)                               ║");
        System.out.println("║ 4. Exit Application                                            ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");
        System.out.print("\n📌 Select option: ");
        
        try {
            int choice = Integer.parseInt(scanner.nextLine());
            
            switch (choice) {
                case 1:
                    handleLogin();
                    break;
                case 2:
                    handleRegistration();
                    break;
                case 3:
                    adminPanel();
                    break;
                case 4:
                    running = false;
                    break;
                default:
                    System.out.println("❌ Invalid option! Please try again.");
            }
        } catch (NumberFormatException e) {
            System.out.println("❌ Please enter a valid number!");
        }
    }

    private void showMainMenu() {
        if (!loginService.validateSession()) {
            return;
        }
        
        User user = loginService.getCurrentUser();
        
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.printf("║  👤 Welcome, %-48s ║%n", user.getFullName());
        System.out.printf("║  💰 Wallet Balance: ₹%-42.2f ║%n", user.getWalletBalance());
        System.out.println("╠════════════════════════════════════════════════════════════════╣");
        System.out.println("║  MAIN MENU                                                     ║");
        System.out.println("╠════════════════════════════════════════════════════════════════╣");
        System.out.println("║  1. 📋 View My Bills                                           ║");
        System.out.println("║  2. 💳 Pay Bills                                               ║");
        System.out.println("║  3. 💰 Wallet Management                                       ║");
        System.out.println("║  4. 📊 Transaction History                                     ║");
        System.out.println("║  5. 👤 Account Management                                      ║");
        System.out.println("║  6. 🤖 Chatbot Assistant                                       ║");
        System.out.println("║  7. 📞 Contact Support                                         ║");
        System.out.println("║  8. 🚪 Logout                                                  ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");
        System.out.print("\n📌 Select option: ");
        
        try {
            int choice = Integer.parseInt(scanner.nextLine());
            
            switch (choice) {
                case 1:
                    handleViewBills();
                    break;
                case 2:
                    handlePayBills();
                    break;
                case 3:
                    handleWalletManagement();
                    break;
                case 4:
                    handleTransactionHistory();
                    break;
                case 5:
                    handleAccountManagement();
                    break;
                case 6:
                    handleChatbot();
                    break;
                case 7:
                    handleContactSupport();
                    break;
                case 8:
                    handleLogout();
                    break;
                default:
                    System.out.println("❌ Invalid option! Please try again.");
            }
        } catch (NumberFormatException e) {
            System.out.println("❌ Please enter a valid number!");
        }
    }

    // ============ AUTHENTICATION HANDLERS ============

    private void handleLogin() {
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║                     🔓 USER LOGIN                             ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");
        
        System.out.print("\nEnter Username: ");
        String username = scanner.nextLine().trim();
        
        System.out.print("Enter Password: ");
        String password = scanner.nextLine().trim();
        
        User user = loginService.login(username, password);
        
        if (user != null) {
            chatbot.setCurrentUser(user);
        }
    }

    private void handleRegistration() {
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║                   📝 USER REGISTRATION                        ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");
        
        try {
            System.out.print("\nEnter Username (4-20 characters): ");
            String username = scanner.nextLine().trim();
            
            System.out.print("Enter Email: ");
            String email = scanner.nextLine().trim();
            
            System.out.print("Enter Phone (10 digits): ");
            String phone = scanner.nextLine().trim();
            
            System.out.print("Enter Full Name: ");
            String fullName = scanner.nextLine().trim();
            
            System.out.print("Enter Address: ");
            String address = scanner.nextLine().trim();
            
            System.out.print("Create Password (minimum 6 characters): ");
            String password = scanner.nextLine().trim();
            
            System.out.print("Confirm Password: ");
            String confirmPassword = scanner.nextLine().trim();
            
            if (!password.equals(confirmPassword)) {
                System.out.println("❌ Passwords do not match!");
                return;
            }
            
            User user = new User(username, email, phone, password, fullName);
            user.setAddress(address);
            user.setWalletBalance(BigDecimal.ZERO);
            
            if (userService.registerUser(user)) {
                System.out.println("\n✅ Registration successful!");
                System.out.println("You can now login with your credentials.");
            }
        } catch (Exception e) {
            System.err.println("❌ Registration failed: " + e.getMessage());
        }
    }

    private void adminPanel() {
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║                      👨‍💼 ADMIN PANEL                          ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");
        System.out.println("\n1. View All Utilities");
        System.out.println("2. Add New Utility");
        System.out.println("3. Back to Main Menu");
        System.out.print("\n📌 Select option: ");
        
        try {
            int choice = Integer.parseInt(scanner.nextLine());
            
            switch (choice) {
                case 1:
                    utilityService.displayAllUtilities();
                    break;
                case 2:
                    addNewUtility();
                    break;
                case 3:
                    break;
                default:
                    System.out.println("❌ Invalid option!");
            }
        } catch (NumberFormatException e) {
            System.out.println("❌ Please enter a valid number!");
        }
    }

    // ============ BILL HANDLERS ============

    private void handleViewBills() {
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║                      📋 MY BILLS                              ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");
        
        User user = loginService.getCurrentUser();
        
        System.out.println("\n1. View All Bills");
        System.out.println("2. View Unpaid Bills");
        System.out.println("3. View Bill Details");
        System.out.println("4. Back to Main Menu");
        System.out.print("\n📌 Select option: ");
        
        try {
            int choice = Integer.parseInt(scanner.nextLine());
            
            switch (choice) {
                case 1:
                    billService.displayUserBills(user.getUserId());
                    break;
                case 2:
                    billService.displayUnpaidBills(user.getUserId());
                    break;
                case 3:
                    viewBillDetails(user);
                    break;
                case 4:
                    break;
                default:
                    System.out.println("❌ Invalid option!");
            }
        } catch (NumberFormatException e) {
            System.out.println("❌ Please enter a valid number!");
        }
    }

    private void viewBillDetails(User user) {
        System.out.print("\nEnter Bill ID or Bill Number: ");
        String input = scanner.nextLine().trim();
        
        Bill bill = null;
        
        try {
            int billId = Integer.parseInt(input);
            bill = billService.getBillById(billId);
        } catch (NumberFormatException e) {
            bill = billService.getBillByNumber(input);
        }
        
        if (bill != null && bill.getUserId() == user.getUserId()) {
            System.out.println(bill);
        } else {
            System.out.println("❌ Bill not found!");
        }
    }

    private void handlePayBills() {
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║                      💳 PAY BILLS                             ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");
        
        User user = loginService.getCurrentUser();
        
        System.out.println("\n1. Pay a Specific Bill");
        System.out.println("2. Make Direct Payment");
        System.out.println("3. Back to Main Menu");
        System.out.print("\n📌 Select option: ");
        
        try {
            int choice = Integer.parseInt(scanner.nextLine());
            
            switch (choice) {
                case 1:
                    paySpecificBill(user);
                    break;
                case 2:
                    makeDirectPayment(user);
                    break;
                case 3:
                    break;
                default:
                    System.out.println("❌ Invalid option!");
            }
        } catch (NumberFormatException e) {
            System.out.println("❌ Please enter a valid number!");
        }
    }

    private void paySpecificBill(User user) {
        System.out.print("\nEnter Bill ID: ");
        
        try {
            int billId = Integer.parseInt(scanner.nextLine());
            Bill bill = billService.getBillById(billId);
            
            if (bill == null || bill.getUserId() != user.getUserId()) {
                System.out.println("❌ Bill not found!");
                return;
            }
            
            if (bill.getBillStatus() == BillStatus.PAID) {
                System.out.println("❌ This bill is already paid!");
                return;
            }
            
            System.out.println(bill);
            System.out.printf("\n💵 Amount to pay: ₹%.2f%n", bill.getBillAmount());
            
            selectPaymentMethodForBill(user, billId);
        } catch (NumberFormatException e) {
            System.out.println("❌ Please enter a valid bill ID!");
        }
    }

    private void makeDirectPayment(User user) {
        System.out.print("\nEnter payment amount (₹): ");
        
        try {
            BigDecimal amount = new BigDecimal(scanner.nextLine());
            
            System.out.println("\nPayment Description: ");
            String description = scanner.nextLine().trim();
            
            selectPaymentMethodForAmount(user, amount, description);
        } catch (NumberFormatException e) {
            System.out.println("❌ Please enter a valid amount!");
        }
    }

    private void selectPaymentMethodForBill(User user, int billId) {
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║              💳 SELECT PAYMENT METHOD                         ║");
        System.out.println("╠════════════════════════════════════════════════════════════════╣");
        System.out.println("║ 1. 📱 UPI                                                      ║");
        System.out.println("║ 2. 💳 Credit Card                                              ║");
        System.out.println("║ 3. 🏦 Debit Card                                               ║");
        System.out.println("║ 4. 🌐 Net Banking                                              ║");
        System.out.println("║ 5. 💼 Wallet                                                   ║");
        System.out.println("║ 6. 💵 Cash (Offline)                                           ║");
        System.out.println("║ 7. Back to Menu                                                ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");
        System.out.print("\n📌 Select payment method: ");
        
        try {
            int choice = Integer.parseInt(scanner.nextLine());
            PaymentMode mode = null;
            
            switch (choice) {
                case 1:
                    mode = PaymentMode.UPI;
                    break;
                case 2:
                    mode = PaymentMode.CREDIT_CARD;
                    break;
                case 3:
                    mode = PaymentMode.DEBIT_CARD;
                    break;
                case 4:
                    mode = PaymentMode.NET_BANKING;
                    break;
                case 5:
                    mode = PaymentMode.WALLET;
                    break;
                case 6:
                    mode = PaymentMode.CASH;
                    break;
                case 7:
                    return;
                default:
                    System.out.println("❌ Invalid option!");
                    return;
            }
            
            if (mode != null) {
                paymentService.payBill(user, billId, mode, scanner);
                loginService.refreshCurrentUser();
            }
        } catch (NumberFormatException e) {
            System.out.println("❌ Please enter a valid number!");
        }
    }

    private void selectPaymentMethodForAmount(User user, BigDecimal amount, String description) {
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║              💳 SELECT PAYMENT METHOD                         ║");
        System.out.println("╠════════════════════════════════════════════════════════════════╣");
        System.out.println("║ 1. 📱 UPI                                                      ║");
        System.out.println("║ 2. 💳 Credit Card                                              ║");
        System.out.println("║ 3. 🏦 Debit Card                                               ║");
        System.out.println("║ 4. 🌐 Net Banking                                              ║");
        System.out.println("║ 5. 💼 Wallet                                                   ║");
        System.out.println("║ 6. 💵 Cash (Offline)                                           ║");
        System.out.println("║ 7. Back to Menu                                                ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");
        System.out.print("\n📌 Select payment method: ");
        
        try {
            int choice = Integer.parseInt(scanner.nextLine());
            PaymentMode mode = null;
            
            switch (choice) {
                case 1:
                    mode = PaymentMode.UPI;
                    break;
                case 2:
                    mode = PaymentMode.CREDIT_CARD;
                    break;
                case 3:
                    mode = PaymentMode.DEBIT_CARD;
                    break;
                case 4:
                    mode = PaymentMode.NET_BANKING;
                    break;
                case 5:
                    mode = PaymentMode.WALLET;
                    break;
                case 6:
                    mode = PaymentMode.CASH;
                    break;
                case 7:
                    return;
                default:
                    System.out.println("❌ Invalid option!");
                    return;
            }
            
            if (mode != null) {
                paymentService.makePayment(user, amount, mode, description, scanner);
                loginService.refreshCurrentUser();
            }
        } catch (NumberFormatException e) {
            System.out.println("❌ Please enter a valid number!");
        }
    }

    // ============ WALLET HANDLERS ============

    private void handleWalletManagement() {
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║                   💰 WALLET MANAGEMENT                        ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");
        
        User user = loginService.getCurrentUser();
        
        System.out.printf("\n💵 Current Wallet Balance: ₹%.2f%n", user.getWalletBalance());
        
        System.out.println("\n1. Add Money to Wallet");
        System.out.println("2. View Wallet History");
        System.out.println("3. Back to Main Menu");
        System.out.print("\n📌 Select option: ");
        
        try {
            int choice = Integer.parseInt(scanner.nextLine());
            
            switch (choice) {
                case 1:
                    addMoneyToWallet(user);
                    break;
                case 2:
                    viewWalletHistory(user);
                    break;
                case 3:
                    break;
                default:
                    System.out.println("❌ Invalid option!");
            }
        } catch (NumberFormatException e) {
            System.out.println("❌ Please enter a valid number!");
        }
    }

    private void addMoneyToWallet(User user) {
        System.out.print("\nEnter amount to add (₹): ");
        
        try {
            BigDecimal amount = new BigDecimal(scanner.nextLine());
            
            System.out.println("\n1. Credit Card");
            System.out.println("2. Debit Card");
            System.out.println("3. Net Banking");
            System.out.println("4. UPI");
            System.out.print("\n📌 Select payment method: ");
            
            int choice = Integer.parseInt(scanner.nextLine());
            PaymentMode mode = null;
            
            switch (choice) {
                case 1:
                    mode = PaymentMode.CREDIT_CARD;
                    break;
                case 2:
                    mode = PaymentMode.DEBIT_CARD;
                    break;
                case 3:
                    mode = PaymentMode.NET_BANKING;
                    break;
                case 4:
                    mode = PaymentMode.UPI;
                    break;
                default:
                    System.out.println("❌ Invalid option!");
                    return;
            }
            
            paymentService.rechargeWallet(user, amount, mode, scanner);
            loginService.refreshCurrentUser();
        } catch (NumberFormatException e) {
            System.out.println("❌ Please enter a valid amount!");
        }
    }

    private void viewWalletHistory(User user) {
        System.out.println("\n📱 Wallet Transaction History:");
        List<Transaction> transactions = transactionService.getTransactionsByType(
            user.getUserId(), Transaction.TransactionType.WALLET_RECHARGE);
        
        if (transactions.isEmpty()) {
            System.out.println("No wallet transactions found.");
            return;
        }
        
        for (Transaction txn : transactions) {
            System.out.printf("✓ ₹%.2f added on %s%n", 
                txn.getAmount(), DateUtil.formatDateTime(txn.getTransactionDate()));
        }
    }

    // ============ TRANSACTION HANDLERS ============

    private void handleTransactionHistory() {
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║                   📊 TRANSACTION HISTORY                      ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");
        
        User user = loginService.getCurrentUser();
        
        System.out.println("\n1. View Full Statement");
        System.out.println("2. View Mini Statement (Last 5)");
        System.out.println("3. View by Transaction Type");
        System.out.println("4. Export Statement");
        System.out.println("5. Back to Main Menu");
        System.out.print("\n📌 Select option: ");
        
        try {
            int choice = Integer.parseInt(scanner.nextLine());
            
            switch (choice) {
                case 1:
                    transactionService.displayTransactionHistory(user.getUserId());
                    break;
                case 2:
                    transactionService.displayMiniStatement(user.getUserId());
                    break;
                case 3:
                    viewTransactionByType(user);
                    break;
                case 4:
                    transactionService.generateStatement(user);
                    break;
                case 5:
                    break;
                default:
                    System.out.println("❌ Invalid option!");
            }
        } catch (NumberFormatException e) {
            System.out.println("❌ Please enter a valid number!");
        }
    }

    private void viewTransactionByType(User user) {
        System.out.println("\nTransaction Types:");
        System.out.println("1. Payment");
        System.out.println("2. Refund");
        System.out.println("3. Wallet Recharge");
        System.out.println("4. Transfer");
        System.out.print("\n📌 Select type: ");
        
        try {
            int choice = Integer.parseInt(scanner.nextLine());
            Transaction.TransactionType type = null;
            
            switch (choice) {
                case 1:
                    type = Transaction.TransactionType.PAYMENT;
                    break;
                case 2:
                    type = Transaction.TransactionType.REFUND;
                    break;
                case 3:
                    type = Transaction.TransactionType.WALLET_RECHARGE;
                    break;
                case 4:
                    type = Transaction.TransactionType.TRANSFER;
                    break;
                default:
                    System.out.println("❌ Invalid option!");
                    return;
            }
            
            var transactions = transactionService.getTransactionsByType(
                user.getUserId(), type);
            
            if (transactions.isEmpty()) {
                System.out.println("No " + type + " transactions found.");
                return;
            }
            
            System.out.println("\n" + type + " TRANSACTIONS:");
            for (Transaction txn : transactions) {
                System.out.printf("• ₹%.2f - %s (%s)%n", 
                    txn.getAmount(), txn.getDescription(), 
                    DateUtil.formatDateTime(txn.getTransactionDate()));
            }
        } catch (NumberFormatException e) {
            System.out.println("❌ Please enter a valid number!");
        }
    }

    // ============ ACCOUNT HANDLERS ============

    private void handleAccountManagement() {
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║                   👤 ACCOUNT MANAGEMENT                       ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");
        
        User user = loginService.getCurrentUser();
        
        System.out.println("\n1. View Profile");
        System.out.println("2. Update Profile");
        System.out.println("3. Change Password");
        System.out.println("4. Deactivate Account");
        System.out.println("5. Back to Main Menu");
        System.out.print("\n📌 Select option: ");
        
        try {
            int choice = Integer.parseInt(scanner.nextLine());
            
            switch (choice) {
                case 1:
                    System.out.println(user);
                    break;
                case 2:
                    updateProfile(user);
                    break;
                case 3:
                    changePassword(user);
                    break;
                case 4:
                    deactivateAccount(user);
                    break;
                case 5:
                    break;
                default:
                    System.out.println("❌ Invalid option!");
            }
        } catch (NumberFormatException e) {
            System.out.println("❌ Please enter a valid number!");
        }
    }

    private void updateProfile(User user) {
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║                     📝 UPDATE PROFILE                         ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");
        
        System.out.println("\n(Press Enter to skip a field)");
        
        System.out.print("\nEmail (" + user.getEmail() + "): ");
        String email = scanner.nextLine().trim();
        if (!email.isEmpty()) user.setEmail(email);
        
        System.out.print("Phone (" + user.getPhone() + "): ");
        String phone = scanner.nextLine().trim();
        if (!phone.isEmpty()) user.setPhone(phone);
        
        System.out.print("Full Name (" + user.getFullName() + "): ");
        String fullName = scanner.nextLine().trim();
        if (!fullName.isEmpty()) user.setFullName(fullName);
        
        System.out.print("Address (" + (user.getAddress() != null ? user.getAddress() : "Not set") + "): ");
        String address = scanner.nextLine().trim();
        if (!address.isEmpty()) user.setAddress(address);
        
        if (userService.updateUserProfile(user)) {
            loginService.refreshCurrentUser();
        }
    }

    private void changePassword(User user) {
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║                   🔐 CHANGE PASSWORD                          ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");
        
        System.out.print("\nCurrent Password: ");
        String currentPassword = scanner.nextLine().trim();
        
        System.out.print("New Password: ");
        String newPassword = scanner.nextLine().trim();
        
        System.out.print("Confirm Password: ");
        String confirmPassword = scanner.nextLine().trim();
        
        if (!newPassword.equals(confirmPassword)) {
            System.out.println("❌ Passwords do not match!");
            return;
        }
        
        userService.changePassword(user.getUserId(), currentPassword, newPassword);
    }

    private void deactivateAccount(User user) {
        System.out.print("\n⚠️ Are you sure you want to deactivate your account? (yes/no): ");
        String confirm = scanner.nextLine().trim().toLowerCase();
        
        if (confirm.equals("yes") || confirm.equals("y")) {
            userService.deactivateAccount(user.getUserId());
            loginService.logout();
        } else {
            System.out.println("Account deactivation cancelled.");
        }
    }

    // ============ CHATBOT HANDLER ============

    private void handleChatbot() {
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║                   🤖 CHATBOT ASSISTANT                        ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");
        System.out.println("\nType 'exit' to return to main menu.");
        System.out.println("Type 'help' for available commands.\n");
        
        User user = loginService.getCurrentUser();
        chatbot.setCurrentUser(user);
        
        while (true) {
            System.out.print("🤖 You: ");
            String input = scanner.nextLine().trim();
            
            if (input.equalsIgnoreCase("exit") || input.equalsIgnoreCase("bye")) {
                System.out.println("🤖 Assistant: Goodbye! Have a great day! 👋\n");
                break;
            }
            
            if (input.isEmpty()) continue;
            
            String response = chatbot.processQuery(input);
            System.out.println("🤖 Assistant: " + response + "\n");
        }
    }

    // ============ SUPPORT HANDLER ============

    private void handleContactSupport() {
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║                   📞 CONTACT SUPPORT                          ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");
        
        System.out.println("\n📧 Email: support@mugateway.com");
        System.out.println("📱 Phone: 1-800-MU-GATEWAY");
        System.out.println("🌐 Website: www.mugateway.com");
        System.out.println("⏰ Support Hours: 24/7");
        System.out.println("\n💬 Common Issues:");
        System.out.println("• Forgot Password? Contact support");
        System.out.println("• Bill Not Showing? Check utility registration");
        System.out.println("• Payment Failed? Try different payment method");
        System.out.println("• Wallet Issues? Contact support for assistance");
    }

    // ============ LOGOUT HANDLER ============

    private void handleLogout() {
        System.out.print("\nAre you sure you want to logout? (yes/no): ");
        String confirm = scanner.nextLine().trim().toLowerCase();
        
        if (confirm.equals("yes") || confirm.equals("y")) {
            loginService.logout();
            System.out.println();
        }
    }

    // ============ UTILITY HANDLER ============

    private void addNewUtility() {
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║                   ⚡ ADD NEW UTILITY                          ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝");
        
        System.out.print("\nUtility Name: ");
        String name = scanner.nextLine().trim();
        
        System.out.println("\nUtility Type:");
        System.out.println("1. ELECTRICITY");
        System.out.println("2. WATER");
        System.out.println("3. GAS");
        System.out.println("4. MOBILE_RECHARGE");
        System.out.println("5. INTERNET");
        System.out.println("6. DTH");
        System.out.print("\n📌 Select type: ");
        
        try {
            int typeChoice = Integer.parseInt(scanner.nextLine());
            UtilityType[] types = UtilityType.values();
            
            if (typeChoice < 1 || typeChoice > types.length) {
                System.out.println("❌ Invalid type!");
                return;
            }
            
            UtilityType type = types[typeChoice - 1];
            
            System.out.print("Provider Name: ");
            String provider = scanner.nextLine().trim();
            
            System.out.print("Description: ");
            String description = scanner.nextLine().trim();
            
            Utility utility = new Utility(name, type, provider, description);
            utilityService.addUtility(utility);
        } catch (NumberFormatException e) {
            System.out.println("❌ Invalid input!");
        }
    }

    // ============ APPLICATION SHUTDOWN ============

    private void closeApplication() {
        System.out.println("\n╔════════════════════════════════════════════════════════════════╗");
        System.out.println("║                  👋 THANK YOU FOR USING MU GATEWAY             ║");
        System.out.println("║                    Please visit again soon!                   ║");
        System.out.println("╚════════════════════════════════════════════════════════════════╝\n");
        
        scanner.close();
        DBConfig.closeConnection();
        System.exit(0);
    }
}