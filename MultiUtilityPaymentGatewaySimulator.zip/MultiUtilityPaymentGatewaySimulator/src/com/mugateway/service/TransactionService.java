package com.mugateway.service;

import com.mugateway.dao.TransactionDAO;
import com.mugateway.model.Transaction;
import com.mugateway.model.Transaction.TransactionType;
import com.mugateway.model.User;
import com.mugateway.util.DateUtil;
import com.mugateway.util.ReceiptGenerator;

import java.math.BigDecimal;
import java.util.List;

public class TransactionService {
    private final TransactionDAO transactionDAO;

    public TransactionService() {
        this.transactionDAO = new TransactionDAO();
    }

    // CREATE - Record transaction (used internally by other services)
    public boolean recordTransaction(Transaction transaction) {
        return transactionDAO.createTransaction(transaction);
    }

    // READ - Get transaction by ID
    public Transaction getTransactionById(int transactionId) {
        return transactionDAO.getTransactionById(transactionId);
    }

    // READ - Get all user transactions
    public List<Transaction> getUserTransactions(int userId) {
        return transactionDAO.getTransactionsByUserId(userId);
    }

    // READ - Get transactions by type
    public List<Transaction> getTransactionsByType(int userId, TransactionType type) {
        return transactionDAO.getTransactionsByType(userId, type);
    }

    // READ - Get recent transactions
    public List<Transaction> getRecentTransactions(int userId, int limit) {
        return transactionDAO.getRecentTransactions(userId, limit);
    }

    // UPDATE - Update transaction remarks
    public boolean updateTransactionRemarks(int transactionId, String remarks) {
        boolean success = transactionDAO.updateTransactionRemarks(transactionId, remarks);
        if (success) {
            System.out.println("✅ Transaction updated!");
        }
        return success;
    }

    // DELETE - Delete transaction
    public boolean deleteTransaction(int transactionId) {
        boolean success = transactionDAO.deleteTransaction(transactionId);
        if (success) {
            System.out.println("✅ Transaction deleted!");
        }
        return success;
    }

    // DELETE - Delete old transactions
    public int deleteOldTransactions(int userId, int daysOld) {
        int count = transactionDAO.deleteOldTransactions(userId, daysOld);
        if (count > 0) {
            System.out.println("✅ Deleted " + count + " old transactions.");
        }
        return count;
    }

    // Display transaction history
    public void displayTransactionHistory(int userId) {
        List<Transaction> transactions = getUserTransactions(userId);
        
        if (transactions.isEmpty()) {
            System.out.println("No transactions found.");
            return;
        }
        
        String line = "═".repeat(115);
        System.out.println("\n" + line);
        System.out.println("║ " + String.format("%-5s │ %-15s │ %-12s │ %-12s │ %-25s │ %-20s", 
            "ID", "TYPE", "AMOUNT", "BALANCE", "DESCRIPTION", "DATE") + " ║");
        System.out.println(line);
        
        for (Transaction txn : transactions) {
            String description = txn.getDescription();
            if (description != null && description.length() > 23) {
                description = description.substring(0, 20) + "...";
            }
            
            System.out.printf("║ %-5d │ %-15s │ ₹%-11.2f │ ₹%-11.2f │ %-25s │ %-20s ║%n",
                txn.getTransactionId(),
                txn.getTransactionType(),
                txn.getAmount(),
                txn.getBalanceAfter() != null ? txn.getBalanceAfter() : BigDecimal.ZERO,
                description != null ? description : "N/A",
                DateUtil.formatDateTime(txn.getTransactionDate())
            );
        }
        
        System.out.println(line);
        System.out.println("Total transactions: " + transactions.size());
    }

    // Display recent transactions (mini statement)
    public void displayMiniStatement(int userId) {
        List<Transaction> transactions = getRecentTransactions(userId, 5);
        
        System.out.println("\n📋 MINI STATEMENT (Last 5 Transactions)");
        
        if (transactions.isEmpty()) {
            System.out.println("No recent transactions.");
            return;
        }
        
        String line = "-".repeat(80);
        System.out.println(line);
        
        for (Transaction txn : transactions) {
            System.out.printf("%s | %s | ₹%.2f | Balance: ₹%.2f%n",
                DateUtil.formatDateTime(txn.getTransactionDate()),
                txn.getTransactionType(),
                txn.getAmount(),
                txn.getBalanceAfter() != null ? txn.getBalanceAfter() : BigDecimal.ZERO
            );
        }
        
        System.out.println(line);
    }

    // Generate full statement
    public void generateStatement(User user) {
        List<Transaction> transactions = getUserTransactions(user.getUserId());
        String statement = ReceiptGenerator.generateTransactionStatement(user, transactions);
        System.out.println(statement);
    }
}