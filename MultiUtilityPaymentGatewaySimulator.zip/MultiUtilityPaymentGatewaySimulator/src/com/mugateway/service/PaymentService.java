package com.mugateway.service;

import com.mugateway.dao.*;
import com.mugateway.model.*;
import com.mugateway.model.Bill.BillStatus;
import com.mugateway.model.Payment.PaymentMode;
import com.mugateway.model.Payment.PaymentStatus;
import com.mugateway.model.Transaction.TransactionType;
import com.mugateway.util.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Scanner;

public class PaymentService {
    private final PaymentDAO paymentDAO;
    private final BillDAO billDAO;
    private final UserDAO userDAO;
    private final TransactionDAO transactionDAO;

    public PaymentService() {
        this.paymentDAO = new PaymentDAO();
        this.billDAO = new BillDAO();
        this.userDAO = new UserDAO();
        this.transactionDAO = new TransactionDAO();
    }

    // CREATE - Process bill payment
    public boolean payBill(User user, int billId, PaymentMode paymentMode, Scanner scanner) {
        Bill bill = billDAO.getBillById(billId);
        
        if (bill == null) {
            System.out.println("❌ Bill not found!");
            return false;
        }
        
        if (bill.getBillStatus() == BillStatus.PAID) {
            System.out.println("❌ This bill is already paid!");
            return false;
        }
        
        if (bill.getUserId() != user.getUserId()) {
            System.out.println("❌ This bill doesn't belong to you!");
            return false;
        }
        
        BigDecimal amount = bill.getBillAmount();
        
        // Check wallet balance for wallet payments
        if (paymentMode == PaymentMode.WALLET) {
            if (user.getWalletBalance().compareTo(amount) < 0) {
                System.out.println("❌ Insufficient wallet balance!");
                System.out.printf("Required: ₹%.2f, Available: ₹%.2f%n", 
                    amount, user.getWalletBalance());
                return false;
            }
        }
        
        // Process payment through gateway
        PaymentGateway.PaymentResult result = PaymentGateway.processPayment(
            paymentMode, amount, scanner);
        
        // Create payment record
        Payment payment = new Payment(user.getUserId(), billId, amount, paymentMode);
        payment.setTransactionRef(result.getTransactionRef());
        payment.setPaymentStatus(result.getStatus());
        payment.setOffline(paymentMode == PaymentMode.CASH);
        payment.setRemarks(result.getMessage());
        
        boolean paymentCreated = paymentDAO.createPayment(payment);
        
        if (result.isSuccess() && paymentCreated) {
            // Update bill status
            billDAO.updateBillStatus(billId, BillStatus.PAID);
            
            // Deduct from wallet if wallet payment
            if (paymentMode == PaymentMode.WALLET) {
                BigDecimal newBalance = user.getWalletBalance().subtract(amount);
                userDAO.updateWalletBalance(user.getUserId(), newBalance);
                user.setWalletBalance(newBalance);
            }
            
            // Record transaction
            recordTransaction(user, payment, TransactionType.PAYMENT, 
                "Bill payment: " + bill.getBillNumber());
            
            // Generate receipt
            payment.setPaymentDate(DateUtil.getCurrentTimestamp());
            ReceiptGenerator.generatePaymentReceipt(payment, user, bill);
            
            // Send notifications
            sendPaymentNotifications(user, payment, bill);
            
            return true;
        }
        
        return false;
    }

    // CREATE - Direct payment (without bill)
    public boolean makePayment(User user, BigDecimal amount, PaymentMode paymentMode, 
                              String description, Scanner scanner) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            System.out.println("❌ Invalid amount!");
            return false;
        }
        
        // Check wallet balance for wallet payments
        if (paymentMode == PaymentMode.WALLET) {
            if (user.getWalletBalance().compareTo(amount) < 0) {
                System.out.println("❌ Insufficient wallet balance!");
                return false;
            }
        }
        
        // Process payment
        PaymentGateway.PaymentResult result = PaymentGateway.processPayment(
            paymentMode, amount, scanner);
        
        // Create payment record
        Payment payment = new Payment(user.getUserId(), null, amount, paymentMode);
        payment.setTransactionRef(result.getTransactionRef());
        payment.setPaymentStatus(result.getStatus());
        payment.setOffline(paymentMode == PaymentMode.CASH);
        payment.setRemarks(description != null ? description : result.getMessage());
        
        boolean paymentCreated = paymentDAO.createPayment(payment);
        
        if (result.isSuccess() && paymentCreated) {
            // Deduct from wallet if wallet payment
            if (paymentMode == PaymentMode.WALLET) {
                BigDecimal newBalance = user.getWalletBalance().subtract(amount);
                userDAO.updateWalletBalance(user.getUserId(), newBalance);
                user.setWalletBalance(newBalance);
            }
            
            // Record transaction
            recordTransaction(user, payment, TransactionType.PAYMENT, 
                description != null ? description : "Direct payment");
            
            // Generate receipt
            payment.setPaymentDate(DateUtil.getCurrentTimestamp());
            ReceiptGenerator.generatePaymentReceipt(payment, user, null);
            
            // Send notifications
            sendPaymentNotifications(user, payment, null);
            
            return true;
        }
        
        return false;
    }

    // CREATE - Wallet recharge
    public boolean rechargeWallet(User user, BigDecimal amount, PaymentMode paymentMode, 
                                  Scanner scanner) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            System.out.println("❌ Invalid amount!");
            return false;
        }
        
        if (paymentMode == PaymentMode.WALLET) {
            System.out.println("❌ Cannot use wallet to recharge wallet!");
            return false;
        }
        
        // Process payment
        PaymentGateway.PaymentResult result = PaymentGateway.processPayment(
            paymentMode, amount, scanner);
        
        if (result.isSuccess()) {
            // Add to wallet
            BigDecimal newBalance = user.getWalletBalance().add(amount);
            userDAO.updateWalletBalance(user.getUserId(), newBalance);
            
            // Create payment record
            Payment payment = new Payment(user.getUserId(), null, amount, paymentMode);
            payment.setTransactionRef(result.getTransactionRef());
            payment.setPaymentStatus(PaymentStatus.SUCCESS);
            payment.setRemarks("Wallet recharge");
            paymentDAO.createPayment(payment);
            
            // Record transaction
            Transaction transaction = new Transaction();
            transaction.setUserId(user.getUserId());
            transaction.setPaymentId(payment.getPaymentId());
            transaction.setTransactionType(TransactionType.WALLET_RECHARGE);
            transaction.setAmount(amount);
            transaction.setBalanceBefore(user.getWalletBalance());
            transaction.setBalanceAfter(newBalance);
            transaction.setDescription("Wallet recharge via " + paymentMode);
            transactionDAO.createTransaction(transaction);
            
            user.setWalletBalance(newBalance);
            
            System.out.printf("✅ Wallet recharged! New balance: ₹%.2f%n", newBalance);
            
            // Send notifications
            SMSService.sendPaymentSuccessSMS(user.getPhone(), result.getTransactionRef(), 
                amount.toString(), "Wallet Recharge");
            EmailService.sendPaymentSuccessEmail(user.getEmail(), user.getUsername(),
                result.getTransactionRef(), amount.toString(), paymentMode.toString(), null);
            
            return true;
        }
        
        return false;
    }

    // READ - Get payment by ID
    public Payment getPaymentById(int paymentId) {
        return paymentDAO.getPaymentById(paymentId);
    }

    // READ - Get payment by transaction reference
    public Payment getPaymentByTransactionRef(String transactionRef) {
        return paymentDAO.getPaymentByTransactionRef(transactionRef);
    }

    // READ - Get all user payments
    public List<Payment> getUserPayments(int userId) {
        return paymentDAO.getPaymentsByUserId(userId);
    }

    // READ - Get successful payments
    public List<Payment> getSuccessfulPayments(int userId) {
        return paymentDAO.getSuccessfulPaymentsByUserId(userId);
    }

    // UPDATE - Update payment status
    public boolean updatePaymentStatus(int paymentId, PaymentStatus status) {
        return paymentDAO.updatePaymentStatus(paymentId, status);
    }

    // UPDATE - Update payment
    public boolean updatePayment(Payment payment) {
        return paymentDAO.updatePayment(payment);
    }

    // DELETE - Delete payment record
    public boolean deletePayment(int paymentId) {
        Payment payment = paymentDAO.getPaymentById(paymentId);
        if (payment == null) {
            System.out.println("❌ Payment not found!");
            return false;
        }
        
        if (payment.getPaymentStatus() == PaymentStatus.SUCCESS) {
            System.out.println("⚠️ Warning: Deleting a successful payment record!");
        }
        
        boolean success = paymentDAO.deletePayment(paymentId);
        if (success) {
            System.out.println("✅ Payment record deleted!");
        }
        return success;
    }

    // Display payment history
    public void displayPaymentHistory(int userId) {
        List<Payment> payments = getUserPayments(userId);
        
        if (payments.isEmpty()) {
            System.out.println("No payment history found.");
            return;
        }
        
        String line = "═".repeat(110);
        System.out.println("\n" + line);
        System.out.println("║ " + String.format("%-5s │ %-20s │ %-12s │ %-12s │ %-10s │ %-10s │ %-20s", 
            "ID", "TRANSACTION REF", "AMOUNT", "MODE", "STATUS", "OFFLINE", "DATE") + " ║");
        System.out.println(line);
        
        for (Payment payment : payments) {
            System.out.printf("║ %-5d │ %-20s │ ₹%-11.2f │ %-12s │ %-10s │ %-10s │ %-20s ║%n",
                payment.getPaymentId(),
                payment.getTransactionRef(),
                payment.getPaymentAmount(),
                payment.getPaymentMode(),
                payment.getPaymentStatus(),
                payment.isOffline() ? "Yes" : "No",
                DateUtil.formatDateTime(payment.getPaymentDate())
            );
        }
        
        System.out.println(line);
        System.out.println("Total payments: " + payments.size());
    }

    // Helper methods
    private void recordTransaction(User user, Payment payment, TransactionType type, String description) {
        Transaction transaction = new Transaction();
        transaction.setUserId(user.getUserId());
        transaction.setPaymentId(payment.getPaymentId());
        transaction.setTransactionType(type);
        transaction.setAmount(payment.getPaymentAmount());
        transaction.setBalanceBefore(user.getWalletBalance().add(
            payment.getPaymentMode() == PaymentMode.WALLET ? payment.getPaymentAmount() : BigDecimal.ZERO));
        transaction.setBalanceAfter(user.getWalletBalance());
        transaction.setDescription(description);
        transactionDAO.createTransaction(transaction);
    }

    private void sendPaymentNotifications(User user, Payment payment, Bill bill) {
        String billNumber = bill != null ? bill.getBillNumber() : null;
        
        // Send SMS
        SMSService.sendPaymentSuccessSMS(
            user.getPhone(),
            payment.getTransactionRef(),
            payment.getPaymentAmount().toString(),
            payment.getPaymentMode().toString()
        );
        
        // Send Email
        EmailService.sendPaymentSuccessEmail(
            user.getEmail(),
            user.getUsername(),
            payment.getTransactionRef(),
            payment.getPaymentAmount().toString(),
            payment.getPaymentMode().toString(),
            billNumber
        );
    }
}