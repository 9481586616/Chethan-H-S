package com.mugateway.service;

import com.mugateway.dao.UserDAO;
import com.mugateway.model.User;
import com.mugateway.util.EmailService;
import com.mugateway.util.SMSService;

import java.math.BigDecimal;
import java.util.List;
import java.util.regex.Pattern;

public class UserService {
    private final UserDAO userDAO;
    
    // Validation patterns
    private static final Pattern EMAIL_PATTERN = 
        Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
    private static final Pattern PHONE_PATTERN = 
        Pattern.compile("^[0-9]{10}$");
    private static final Pattern USERNAME_PATTERN = 
        Pattern.compile("^[a-zA-Z0-9_]{4,20}$");

    public UserService() {
        this.userDAO = new UserDAO();
    }

    // CREATE - Register new user
    public boolean registerUser(User user) {
        // Validate user data
        if (!validateUserData(user)) {
            return false;
        }
        
        // Check if username already exists
        if (userDAO.usernameExists(user.getUsername())) {
            System.out.println("❌ Username already exists!");
            return false;
        }
        
        // Check if email already exists
        if (userDAO.emailExists(user.getEmail())) {
            System.out.println("❌ Email already registered!");
            return false;
        }
        
        // Create user in database
        boolean success = userDAO.createUser(user);
        
        if (success) {
            System.out.println("✅ Registration successful!");
            
            // Send welcome email
            EmailService.sendWelcomeEmail(user.getEmail(), user.getUsername(), user.getFullName());
            
            // Send registration SMS
            SMSService.sendRegistrationSMS(user.getPhone(), user.getUsername());
        }
        
        return success;
    }

    // READ - Get user details
    public User getUserById(int userId) {
        return userDAO.getUserById(userId);
    }

    public User getUserByUsername(String username) {
        return userDAO.getUserByUsername(username);
    }

    public List<User> getAllUsers() {
        return userDAO.getAllUsers();
    }

    // UPDATE - Update user profile
    public boolean updateUserProfile(User user) {
        if (user.getEmail() != null && !isValidEmail(user.getEmail())) {
            System.out.println("❌ Invalid email format!");
            return false;
        }
        
        if (user.getPhone() != null && !isValidPhone(user.getPhone())) {
            System.out.println("❌ Invalid phone number!");
            return false;
        }
        
        boolean success = userDAO.updateUser(user);
        if (success) {
            System.out.println("✅ Profile updated successfully!");
        }
        return success;
    }

    // UPDATE - Change password
    public boolean changePassword(int userId, String oldPassword, String newPassword) {
        User user = userDAO.getUserById(userId);
        
        if (user == null) {
            System.out.println("❌ User not found!");
            return false;
        }
        
        // Verify old password
        User authenticated = userDAO.authenticateUser(user.getUsername(), oldPassword);
        if (authenticated == null) {
            System.out.println("❌ Current password is incorrect!");
            return false;
        }
        
        // Validate new password
        if (!isValidPassword(newPassword)) {
            System.out.println("❌ Password must be at least 6 characters!");
            return false;
        }
        
        boolean success = userDAO.updatePassword(userId, newPassword);
        if (success) {
            System.out.println("✅ Password changed successfully!");
        }
        return success;
    }

    // UPDATE - Add money to wallet
    public boolean addToWallet(int userId, BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            System.out.println("❌ Amount must be positive!");
            return false;
        }
        
        User user = userDAO.getUserById(userId);
        if (user == null) {
            System.out.println("❌ User not found!");
            return false;
        }
        
        BigDecimal newBalance = user.getWalletBalance().add(amount);
        boolean success = userDAO.updateWalletBalance(userId, newBalance);
        
        if (success) {
            System.out.printf("✅ ₹%.2f added to wallet. New balance: ₹%.2f%n", 
                amount, newBalance);
        }
        return success;
    }

    // UPDATE - Deduct from wallet
    public boolean deductFromWallet(int userId, BigDecimal amount) {
        User user = userDAO.getUserById(userId);
        if (user == null) {
            System.out.println("❌ User not found!");
            return false;
        }
        
        if (user.getWalletBalance().compareTo(amount) < 0) {
            System.out.println("❌ Insufficient wallet balance!");
            return false;
        }
        
        BigDecimal newBalance = user.getWalletBalance().subtract(amount);
        return userDAO.updateWalletBalance(userId, newBalance);
    }

    // DELETE - Deactivate account
    public boolean deactivateAccount(int userId) {
        boolean success = userDAO.deactivateUser(userId);
        if (success) {
            System.out.println("✅ Account deactivated successfully!");
        }
        return success;
    }

    // DELETE - Permanently delete account
    public boolean deleteAccount(int userId) {
        boolean success = userDAO.deleteUser(userId);
        if (success) {
            System.out.println("✅ Account deleted permanently!");
        }
        return success;
    }

    // Get wallet balance
    public BigDecimal getWalletBalance(int userId) {
        User user = userDAO.getUserById(userId);
        return user != null ? user.getWalletBalance() : BigDecimal.ZERO;
    }

    // Validation methods
    private boolean validateUserData(User user) {
        if (!isValidUsername(user.getUsername())) {
            System.out.println("❌ Invalid username! Must be 4-20 alphanumeric characters.");
            return false;
        }
        
        if (!isValidEmail(user.getEmail())) {
            System.out.println("❌ Invalid email format!");
            return false;
        }
        
        if (!isValidPhone(user.getPhone())) {
            System.out.println("❌ Invalid phone number! Must be 10 digits.");
            return false;
        }
        
        if (!isValidPassword(user.getPassword())) {
            System.out.println("❌ Password must be at least 6 characters!");
            return false;
        }
        
        return true;
    }

    private boolean isValidUsername(String username) {
        return username != null && USERNAME_PATTERN.matcher(username).matches();
    }

    private boolean isValidEmail(String email) {
        return email != null && EMAIL_PATTERN.matcher(email).matches();
    }

    private boolean isValidPhone(String phone) {
        return phone != null && PHONE_PATTERN.matcher(phone.replaceAll("[^0-9]", "")).matches();
    }

    private boolean isValidPassword(String password) {
        return password != null && password.length() >= 6;
    }
}