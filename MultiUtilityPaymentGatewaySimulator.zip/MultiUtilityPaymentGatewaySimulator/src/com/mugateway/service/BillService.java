package com.mugateway.service;

import com.mugateway.dao.BillDAO;
import com.mugateway.dao.UtilityDAO;
import com.mugateway.model.Bill;
import com.mugateway.model.Bill.BillStatus;
import com.mugateway.model.User;
import com.mugateway.model.Utility;
import com.mugateway.util.DateUtil;
import com.mugateway.util.EmailService;
import com.mugateway.util.ReceiptGenerator;
import com.mugateway.util.SMSService;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

public class BillService {
    private final BillDAO billDAO;
    private final UtilityDAO utilityDAO;

    public BillService() {
        this.billDAO = new BillDAO();
        this.utilityDAO = new UtilityDAO();
    }

    // CREATE - Generate new bill
    public boolean generateBill(int userId, int utilityId, BigDecimal amount, Date dueDate) {
        // Validate utility exists
        Utility utility = utilityDAO.getUtilityById(utilityId);
        if (utility == null) {
            System.out.println("❌ Invalid utility!");
            return false;
        }
        
        // Validate amount
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            System.out.println("❌ Invalid bill amount!");
            return false;
        }
        
        // Validate due date
        if (dueDate == null || dueDate.before(DateUtil.getCurrentDate())) {
            System.out.println("❌ Due date must be in the future!");
            return false;
        }
        
        // Generate bill number
        String billNumber = billDAO.generateBillNumber(utilityId);
        
        Bill bill = new Bill(userId, utilityId, billNumber, amount, dueDate);
        
        boolean success = billDAO.createBill(bill);
        if (success) {
            System.out.println("✅ Bill generated successfully!");
            System.out.println("Bill Number: " + billNumber);
        }
        return success;
    }

    // READ - Get bill by ID
    public Bill getBillById(int billId) {
        return billDAO.getBillById(billId);
    }

    // READ - Get bill by number
    public Bill getBillByNumber(String billNumber) {
        return billDAO.getBillByNumber(billNumber);
    }

    // READ - Get all bills for user
    public List<Bill> getUserBills(int userId) {
        return billDAO.getBillsByUserId(userId);
    }

    // READ - Get unpaid bills for user
    public List<Bill> getUnpaidBills(int userId) {
        return billDAO.getUnpaidBillsByUserId(userId);
    }

    // READ - Get overdue bills
    public List<Bill> getOverdueBills() {
        return billDAO.getOverdueBills();
    }

    // UPDATE - Update bill status
    public boolean updateBillStatus(int billId, BillStatus status) {
        boolean success = billDAO.updateBillStatus(billId, status);
        if (success) {
            System.out.println("✅ Bill status updated to: " + status);
        }
        return success;
    }

    // UPDATE - Update bill details
    public boolean updateBill(Bill bill) {
        boolean success = billDAO.updateBill(bill);
        if (success) {
            System.out.println("✅ Bill updated successfully!");
        }
        return success;
    }

    // UPDATE - Mark overdue bills
    public int markOverdueBills() {
        int count = billDAO.markOverdueBills();
        if (count > 0) {
            System.out.println("✅ " + count + " bills marked as overdue.");
        }
        return count;
    }

    // DELETE - Delete bill
    public boolean deleteBill(int billId) {
        Bill bill = billDAO.getBillById(billId);
        if (bill == null) {
            System.out.println("❌ Bill not found!");
            return false;
        }
        
        if (bill.getBillStatus() == BillStatus.PAID) {
            System.out.println("❌ Cannot delete a paid bill!");
            return false;
        }
        
        boolean success = billDAO.deleteBill(billId);
        if (success) {
            System.out.println("✅ Bill deleted successfully!");
        }
        return success;
    }

    // Send bill reminder
    public void sendBillReminder(Bill bill, User user) {
        Utility utility = utilityDAO.getUtilityById(bill.getUtilityId());
        
        EmailService.sendBillReminderEmail(
            user.getEmail(),
            user.getUsername(),
            bill.getBillNumber(),
            utility != null ? utility.getUtilityName() : "Utility",
            bill.getBillAmount().toString(),
            DateUtil.formatDate(bill.getDueDate())
        );
        
        SMSService.sendBillReminderSMS(
            user.getPhone(),
            bill.getBillNumber(),
            bill.getBillAmount().toString(),
            DateUtil.formatDate(bill.getDueDate())
        );
    }

    // Display user bills
    public void displayUserBills(int userId) {
        List<Bill> bills = getUserBills(userId);
        
        if (bills.isEmpty()) {
            System.out.println("No bills found.");
            return;
        }
        
        String line = "═".repeat(100);
        System.out.println("\n" + line);
        System.out.println("║ " + String.format("%-5s │ %-15s │ %-20s │ %-12s │ %-12s │ %-10s", 
            "ID", "BILL NUMBER", "UTILITY", "AMOUNT", "DUE DATE", "STATUS") + " ║");
        System.out.println(line);
        
        for (Bill bill : bills) {
            System.out.printf("║ %-5d │ %-15s │ %-20s │ ₹%-11.2f │ %-12s │ %-10s ║%n",
                bill.getBillId(),
                bill.getBillNumber(),
                bill.getUtilityName(),
                bill.getBillAmount(),
                DateUtil.formatDate(bill.getDueDate()),
                bill.getBillStatus()
            );
        }
        
        System.out.println(line);
        System.out.println("Total bills: " + bills.size());
    }

    // Display unpaid bills
    public void displayUnpaidBills(int userId) {
        List<Bill> bills = getUnpaidBills(userId);
        
        if (bills.isEmpty()) {
            System.out.println("✅ No pending bills. All bills are paid!");
            return;
        }
        
        System.out.println("\n⚠️ PENDING BILLS:");
        String line = "═".repeat(100);
        System.out.println(line);
        System.out.println("║ " + String.format("%-5s │ %-15s │ %-20s │ %-12s │ %-12s │ %-10s", 
            "ID", "BILL NUMBER", "UTILITY", "AMOUNT", "DUE DATE", "STATUS") + " ║");
        System.out.println(line);
        
        BigDecimal totalDue = BigDecimal.ZERO;
        for (Bill bill : bills) {
            System.out.printf("║ %-5d │ %-15s │ %-20s │ ₹%-11.2f │ %-12s │ %-10s ║%n",
                bill.getBillId(),
                bill.getBillNumber(),
                bill.getUtilityName(),
                bill.getBillAmount(),
                DateUtil.formatDate(bill.getDueDate()),
                bill.getBillStatus()
            );
            totalDue = totalDue.add(bill.getBillAmount());
        }
        
        System.out.println(line);
        System.out.printf("Total pending: ₹%.2f (%d bills)%n", totalDue, bills.size());
    }
}