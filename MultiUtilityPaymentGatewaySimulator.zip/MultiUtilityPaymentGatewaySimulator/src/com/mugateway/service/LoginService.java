package com.mugateway.service;

import com.mugateway.dao.UserDAO;
import com.mugateway.model.User;
import com.mugateway.util.EmailService;
import com.mugateway.util.SMSService;

public class LoginService {
    private final UserDAO userDAO;
    private User currentUser;

    public LoginService() {
        this.userDAO = new UserDAO();
        this.currentUser = null;
    }

    // LOGIN - Authenticate user
    public User login(String username, String password) {
        System.out.println("\n⏳ Authenticating...");
        
        User user = userDAO.authenticateUser(username, password);
        
        if (user != null) {
            currentUser = user;
            System.out.println("✅ Login successful! Welcome, " + user.getFullName() + "!");
            
            // Send login alert email
            EmailService.sendLoginAlertEmail(user.getEmail(), user.getUsername());
            
            // Send login alert SMS
            SMSService.sendLoginAlertSMS(user.getPhone(), user.getUsername());
            
            return user;
        } else {
            System.out.println("❌ Invalid username or password!");
            return null;
        }
    }

    // LOGOUT - Clear current session
    public void logout() {
        if (currentUser != null) {
            System.out.println("👋 Goodbye, " + currentUser.getFullName() + "!");
            currentUser = null;
        }
    }

    // Get current logged-in user
    public User getCurrentUser() {
        return currentUser;
    }

    // Check if user is logged in
    public boolean isLoggedIn() {
        return currentUser != null;
    }

    // Refresh current user data
    public void refreshCurrentUser() {
        if (currentUser != null) {
            currentUser = userDAO.getUserById(currentUser.getUserId());
        }
    }

    // Validate session
    public boolean validateSession() {
        if (currentUser == null) {
            System.out.println("⚠️ Please login first!");
            return false;
        }
        
        // Refresh user data to check if still active
        User user = userDAO.getUserById(currentUser.getUserId());
        if (user == null || !user.isActive()) {
            System.out.println("⚠️ Session expired. Please login again!");
            currentUser = null;
            return false;
        }
        
        currentUser = user;
        return true;
    }
}