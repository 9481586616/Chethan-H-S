package com.mugateway.service;

import com.mugateway.model.*;
import com.mugateway.dao.*;
import com.mugateway.util.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.regex.*;
import java.util.stream.Collectors;

/**
 * ChatbotService provides advanced natural language processing and intelligent
 * response generation for user queries. It manages conversation context,
 * extracts intents, and provides personalized assistance.
 */
public class ChatbotService {
    
    private final UserService userService;
    private final BillService billService;
    private final PaymentService paymentService;
    private final TransactionService transactionService;
    private final UtilityService utilityService;
    
    // Conversation context
    private User currentUser;
    private StringBuilder conversationHistory;
    private LocalDateTime lastInteraction;
    private String lastIntent;
    private Map<String, Object> sessionContext;
    
    // Intent definitions
    private static final Map<String, List<String>> INTENT_KEYWORDS = new HashMap<>();
    
    // Response templates
    private static final Map<String, List<String>> RESPONSE_TEMPLATES = new HashMap<>();
    
    // Regular expressions for extracting data
    private static final Pattern AMOUNT_PATTERN = Pattern.compile("₹?\\s*(\\d+(?:\\.\\d{2})?)");
    private static final Pattern BILL_ID_PATTERN = Pattern.compile("bill\\s*#?\\s*(\\d+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern PHONE_PATTERN = Pattern.compile("\\b(\\d{10})\\b");
    private static final Pattern DATE_PATTERN = Pattern.compile("(\\d{1,2}[/-]\\d{1,2}[/-]\\d{2,4})");
    
    static {
        initializeIntents();
        initializeResponses();
    }
    
    public ChatbotService() {
        this.userService = new UserService();
        this.billService = new BillService();
        this.paymentService = new PaymentService();
        this.transactionService = new TransactionService();
        this.utilityService = new UtilityService();
        
        this.conversationHistory = new StringBuilder();
        this.sessionContext = new HashMap<>();
        this.lastInteraction = LocalDateTime.now();
    }
    
    /**
     * Initialize intent keywords mapping
     */
    private static void initializeIntents() {
        // Balance inquiry intents
        INTENT_KEYWORDS.put("BALANCE", Arrays.asList(
            "balance", "wallet", "how much", "account balance", "rupees",
            "check balance", "current balance", "available balance", "money",
            "cash", "funds", "deposit", "credit"
        ));
        
        // Bill-related intents
        INTENT_KEYWORDS.put("BILLS", Arrays.asList(
            "bill", "bills", "pending", "unpaid", "due", "electricity",
            "water", "gas", "recharge", "internet", "dth", "mobile",
            "outstanding", "amount due", "pay bill"
        ));
        
        // Payment intents
        INTENT_KEYWORDS.put("PAYMENT", Arrays.asList(
            "pay", "payment", "submit", "process", "transaction",
            "transfer", "send", "remit", "settle", "clear",
            "receipt", "paid", "invoice", "expense"
        ));
        
        // Wallet recharge intents
        INTENT_KEYWORDS.put("RECHARGE", Arrays.asList(
            "recharge", "add", "top-up", "topup", "deposit",
            "fund", "reload", "credit wallet", "walletrecharge"
        ));
        
        // History intents
        INTENT_KEYWORDS.put("HISTORY", Arrays.asList(
            "history", "statement", "transaction", "past", "previous",
            "record", "activity", "log", "mini statement", "summary"
        ));
        
        // Profile intents
        INTENT_KEYWORDS.put("PROFILE", Arrays.asList(
            "profile", "account", "information", "details", "personal",
            "name", "email", "phone", "address", "username"
        ));
        
        // Help intents
        INTENT_KEYWORDS.put("HELP", Arrays.asList(
            "help", "assist", "support", "guidance", "guide",
            "how to", "explain", "clarify", "problem", "issue"
        ));
        
        // Greeting intents
        INTENT_KEYWORDS.put("GREETING", Arrays.asList(
            "hello", "hi", "hey", "greetings", "hallo", "namaste",
            "good morning", "good afternoon", "good evening", "welcome"
        ));
        
        // Goodbye intents
        INTENT_KEYWORDS.put("GOODBYE", Arrays.asList(
            "bye", "goodbye", "farewell", "see you", "take care",
            "thank you", "thanks", "exit", "quit", "stop", "done"
        ));
        
        // Notification intents
        INTENT_KEYWORDS.put("NOTIFICATIONS", Arrays.asList(
            "notification", "alert", "alert", "message", "sms", "email",
            "news", "update", "reminder", "notify"
        ));
        
        // Complaint intents
        INTENT_KEYWORDS.put("COMPLAINT", Arrays.asList(
            "complaint", "issue", "problem", "error", "bug", "not working",
            "failed", "failure", "broken", "crash", "complain"
        ));
        
        // Status intents
        INTENT_KEYWORDS.put("STATUS", Arrays.asList(
            "status", "where", "check", "track", "what", "when",
            "how long", "pending", "progress", "processing"
        ));
    }
    
    /**
     * Initialize response templates
     */
    private static void initializeResponses() {
        // Balance responses
        RESPONSE_TEMPLATES.put("BALANCE", Arrays.asList(
            "Your current wallet balance is ₹{amount}. Would you like to recharge or make a payment?",
            "💰 Wallet Balance: ₹{amount}",
            "You have ₹{amount} available in your wallet.",
            "Your account balance is ₹{amount}."
        ));
        
        // Bill responses
        RESPONSE_TEMPLATES.put("BILLS", Arrays.asList(
            "You have {count} pending bills totaling ₹{total}. Would you like to view details?",
            "📋 Bills: You have {count} unpaid bills.",
            "Your bills for {utilities} are available. Shall I show you the details?",
            "Current bills: {count} pending with total amount ₹{total}"
        ));
        
        // Payment confirmation
        RESPONSE_TEMPLATES.put("PAYMENT_SUCCESS", Arrays.asList(
            "✅ Payment of ₹{amount} has been processed successfully!",
            "Payment received! ₹{amount} has been debited from your account.",
            "💳 Your payment of ₹{amount} is confirmed. Transaction ID: {txnId}",
            "Success! You paid ₹{amount} on {date}"
        ));
        
        // Payment failure
        RESPONSE_TEMPLATES.put("PAYMENT_FAILED", Arrays.asList(
            "❌ Payment failed: {reason}. Please try again or contact support.",
            "Transaction could not be completed: {reason}",
            "Sorry, the payment failed. Error: {reason}",
            "Unable to process payment: {reason}"
        ));
        
        // History responses
        RESPONSE_TEMPLATES.put("HISTORY", Arrays.asList(
            "📊 You have {count} transactions in total.",
            "Your recent transactions: {details}",
            "Last {count} transactions processed successfully.",
            "Transaction history showing {count} records."
        ));
        
        // Help responses
        RESPONSE_TEMPLATES.put("HELP", Arrays.asList(
            "🆘 I can help you with: Checking balance, viewing bills, making payments, recharging wallet, viewing history, and account management.",
            "Available commands: Balance, Bills, Payment, History, Profile, Recharge, Help",
            "What do you need assistance with? I can help with bills, payments, wallet, and account info.",
            "Try asking about: My balance, pending bills, recent payments, or account details."
        ));
        
        // Greeting responses
        RESPONSE_TEMPLATES.put("GREETING", Arrays.asList(
            "👋 Hello! How can I assist you today?",
            "Welcome! What would you like to do?",
            "Hi there! How can I help you?",
            "Greetings! What can I do for you?"
        ));
        
        // Goodbye responses
        RESPONSE_TEMPLATES.put("GOODBYE", Arrays.asList(
            "👋 Thank you for using MU Gateway! Have a great day!",
            "Goodbye! Feel free to contact us anytime.",
            "See you soon! Take care!",
            "Thank you for visiting. Goodbye!"
        ));
    }
    
    /**
     * Process user query and generate intelligent response
     */
    public String processQuery(String query) {
        if (query == null || query.trim().isEmpty()) {
            return getRandomResponse(RESPONSE_TEMPLATES.get("HELP"));
        }
        
        // Update conversation context
        this.lastInteraction = LocalDateTime.now();
        this.conversationHistory.append("\nUser: ").append(query);
        
        // Extract intent from query
        String intent = extractIntent(query);
        this.lastIntent = intent;
        
        String response = "";
        
        switch (intent) {
            case "BALANCE":
                response = handleBalanceQuery();
                break;
            case "BILLS":
                response = handleBillsQuery(query);
                break;
            case "PAYMENT":
                response = handlePaymentQuery(query);
                break;
            case "RECHARGE":
                response = handleRechargeQuery();
                break;
            case "HISTORY":
                response = handleHistoryQuery(query);
                break;
            case "PROFILE":
                response = handleProfileQuery();
                break;
            case "HELP":
                response = handleHelpQuery(query);
                break;
            case "GREETING":
                response = handleGreetingQuery();
                break;
            case "GOODBYE":
                response = handleGoodbyeQuery();
                break;
            case "NOTIFICATIONS":
                response = handleNotificationsQuery();
                break;
            case "COMPLAINT":
                response = handleComplaintQuery(query);
                break;
            case "STATUS":
                response = handleStatusQuery(query);
                break;
            default:
                response = handleUnknownQuery(query);
        }
        
        // Store response in conversation history
        this.conversationHistory.append("\nAssistant: ").append(response);
        
        return response;
    }
    
    /**
     * Extract intent from user query
     */
    private String extractIntent(String query) {
        String normalizedQuery = query.toLowerCase();
        int maxMatches = 0;
        String detectedIntent = "HELP";
        
        for (Map.Entry<String, List<String>> entry : INTENT_KEYWORDS.entrySet()) {
            int matches = 0;
            for (String keyword : entry.getValue()) {
                if (normalizedQuery.contains(keyword)) {
                    matches++;
                }
            }
            
            if (matches > maxMatches) {
                maxMatches = matches;
                detectedIntent = entry.getKey();
            }
        }
        
        return detectedIntent;
    }
    
    /**
     * Handle balance-related queries
     */
    private String handleBalanceQuery() {
        if (currentUser == null) {
            return "Please login first to check your balance.";
        }
        
        BigDecimal balance = currentUser.getWalletBalance();
        String response = getRandomResponse(RESPONSE_TEMPLATES.get("BALANCE"));
        response = response.replace("{amount}", String.format("%.2f", balance));
        
        return response;
    }
    
    /**
     * Handle bill-related queries
     */
    private String handleBillsQuery(String query) {
        if (currentUser == null) {
            return "Please login to view your bills.";
        }
        
        List<Bill> bills = billService.getUserBills(currentUser.getUserId());
        List<Bill> unpaidBills = bills.stream()
            .filter(b -> b.getBillStatus() == Bill.BillStatus.UNPAID)
            .collect(Collectors.toList());
        
        if (unpaidBills.isEmpty()) {
            return "✅ Great! You have no pending bills. All your bills are paid!";
        }
        
        // Calculate total
        BigDecimal totalAmount = unpaidBills.stream()
            .map(Bill::getBillAmount)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        // Get utility types
        String utilities = unpaidBills.stream()
            .map(b -> b.getUtilityId() > 0 ? "Bill" : "N/A")
            .distinct()
            .collect(Collectors.joining(", "));
        
        String response = getRandomResponse(RESPONSE_TEMPLATES.get("BILLS"));
        response = response.replace("{count}", String.valueOf(unpaidBills.size()));
        response = response.replace("{total}", String.format("%.2f", totalAmount));
        response = response.replace("{utilities}", utilities);
        
        return response;
    }
    
    /**
     * Handle payment queries
     */
    private String handlePaymentQuery(String query) {
        if (currentUser == null) {
            return "Please login to make a payment.";
        }
        
        // Extract amount from query
        Matcher amountMatcher = AMOUNT_PATTERN.matcher(query);
        if (amountMatcher.find()) {
            String amount = amountMatcher.group(1);
            sessionContext.put("payment_amount", amount);
            
            return String.format(
                "You want to pay ₹%s. Which bill would you like to pay? " +
                "(You can say 'pay bill #123' or 'make payment')", 
                amount
            );
        }
        
        // Extract bill ID from query
        Matcher billMatcher = BILL_ID_PATTERN.matcher(query);
        if (billMatcher.find()) {
            int billId = Integer.parseInt(billMatcher.group(1));
            sessionContext.put("payment_bill_id", billId);
            
            Bill bill = billService.getBillById(billId);
            if (bill != null && bill.getUserId() == currentUser.getUserId()) {
                return String.format(
                    "💳 You want to pay Bill #%d of ₹%.2f. Select payment method:\n" +
                    "1. UPI\n2. Card\n3. Net Banking\n4. Wallet\n5. Cash",
                    billId, bill.getBillAmount()
                );
            }
        }
        
        return "What bill would you like to pay? Please provide the bill number or amount.";
    }
    
    /**
     * Handle wallet recharge queries
     */
    private String handleRechargeQuery() {
        if (currentUser == null) {
            return "Please login to recharge your wallet.";
        }
        
        return "💳 How much would you like to add to your wallet? " +
               "Available payment methods: UPI, Card, Net Banking, or Cash payment.";
    }
    
    /**
     * Handle transaction history queries
     */
    private String handleHistoryQuery(String query) {
        if (currentUser == null) {
            return "Please login to view your transaction history.";
        }
        
        List<Transaction> transactions = transactionService
            .getRecentTransactions(currentUser.getUserId(), 10);
        
        if (transactions.isEmpty()) {
            return "📊 No transactions found yet. Start by making a payment or recharging your wallet!";
        }
        
        StringBuilder details = new StringBuilder();
        for (int i = 0; i < Math.min(3, transactions.size()); i++) {
            Transaction txn = transactions.get(i);
            details.append(String.format("\n• ₹%.2f - %s", 
                txn.getAmount(), txn.getDescription()));
        }
        
        String response = getRandomResponse(RESPONSE_TEMPLATES.get("HISTORY"));
        response = response.replace("{count}", String.valueOf(transactions.size()));
        response = response.replace("{details}", details.toString());
        
        return response;
    }
    
    /**
     * Handle profile queries
     */
    private String handleProfileQuery() {
        if (currentUser == null) {
            return "Please login to view your profile.";
        }
        
        return String.format(
            "👤 PROFILE INFORMATION:\n" +
            "Name: %s\n" +
            "Email: %s\n" +
            "Phone: %s\n" +
            "Wallet: ₹%.2f\n" +
            "Status: %s",
            currentUser.getFullName(),
            currentUser.getEmail(),
            currentUser.getPhone(),
            currentUser.getWalletBalance(),
            currentUser.isActive() ? "Active" : "Inactive"
        );
    }
    
    /**
     * Handle help queries
     */
    private String handleHelpQuery(String query) {
        String response = getRandomResponse(RESPONSE_TEMPLATES.get("HELP"));
        
        // Add context-specific help
        if (query.toLowerCase().contains("payment")) {
            response += "\n\nTo make a payment, you can say: 'Pay bill #123' or 'I want to pay ₹500'";
        } else if (query.toLowerCase().contains("balance")) {
            response += "\n\nTo check balance, just ask: 'What's my balance?' or 'Show my wallet'";
        } else if (query.toLowerCase().contains("bill")) {
            response += "\n\nTo view bills, ask: 'Show my bills' or 'What are my pending bills?'";
        }
        
        return response;
    }
    
    /**
     * Handle greeting queries
     */
    private String handleGreetingQuery() {
        if (currentUser != null) {
            return String.format("👋 Hello %s! How can I help you today?", 
                currentUser.getFullName().split(" ")[0]);
        }
        return getRandomResponse(RESPONSE_TEMPLATES.get("GREETING"));
    }
    
    /**
     * Handle goodbye queries
     */
    private String handleGoodbyeQuery() {
        return getRandomResponse(RESPONSE_TEMPLATES.get("GOODBYE"));
    }
    
    /**
     * Handle notification queries
     */
    private String handleNotificationsQuery() {
        if (currentUser == null) {
            return "Please login to view notifications.";
        }
        
        return "📬 Notifications:\n" +
               "• Payment confirmations: Enabled (Email & SMS)\n" +
               "• Bill reminders: Enabled (Email & SMS)\n" +
               "• Wallet alerts: Enabled (SMS)\n" +
               "• Promotional offers: Disabled\n\n" +
               "Would you like to update notification preferences?";
    }
    
    /**
     * Handle complaint queries
     */
    private String handleComplaintQuery(String query) {
        sessionContext.put("complaint_description", query);
        
        return "😟 I'm sorry to hear you're experiencing an issue.\n" +
               "Please describe the problem in detail, and I'll help you resolve it.\n" +
               "Contact support at: support@mugateway.com or 1-800-MU-GATEWAY";
    }
    
    /**
     * Handle status queries
     */
    private String handleStatusQuery(String query) {
        if (currentUser == null) {
            return "Please login to check transaction status.";
        }
        
        // Check for bill status
        Matcher billMatcher = BILL_ID_PATTERN.matcher(query);
        if (billMatcher.find()) {
            int billId = Integer.parseInt(billMatcher.group(1));
            Bill bill = billService.getBillById(billId);
            
            if (bill != null && bill.getUserId() == currentUser.getUserId()) {
                return String.format(
                    "Bill #%d Status:\n" +
                    "Amount: ₹%.2f\n" +
                    "Status: %s\n" +
                    "Due Date: %s",
                    billId, bill.getBillAmount(), 
                    bill.getBillStatus(), bill.getDueDate()
                );
            }
        }
        
        return "What's the transaction or bill number you want to check?";
    }
    
    /**
     * Handle unknown queries with fuzzy matching
     */
    private String handleUnknownQuery(String query) {
        String[] responses = {
            "I'm not sure I understand. Could you rephrase that?",
            "Sorry, I didn't get that. Try asking me about bills, payments, or balance!",
            "That's beyond my current knowledge. Would you like help with something else?",
            "Hmm, I'm not sure about that. Try typing 'help' for available commands."
        };
        
        return responses[new Random().nextInt(responses.length)];
    }
    
    /**
     * Get random response from template
     */
    private String getRandomResponse(List<String> templates) {
        if (templates == null || templates.isEmpty()) {
            return "How can I assist you?";
        }
        return templates.get(new Random().nextInt(templates.size()));
    }
    
    /**
     * Sentiment analysis for user satisfaction
     */
    public double analyzeSentiment(String text) {
        Map<String, Double> positiveWords = new HashMap<>();
        positiveWords.put("good", 0.8);
        positiveWords.put("great", 0.9);
        positiveWords.put("excellent", 1.0);
        positiveWords.put("thank", 0.7);
        positiveWords.put("thanks", 0.7);
        positiveWords.put("happy", 0.9);
        positiveWords.put("pleased", 0.8);
        positiveWords.put("satisfied", 0.8);
        positiveWords.put("amazing", 0.9);
        positiveWords.put("perfect", 0.95);
        
        Map<String, Double> negativeWords = new HashMap<>();
        negativeWords.put("bad", -0.8);
        negativeWords.put("terrible", -1.0);
        negativeWords.put("horrible", -0.95);
        negativeWords.put("angry", -0.9);
        negativeWords.put("frustrated", -0.85);
        negativeWords.put("disappointed", -0.8);
        negativeWords.put("awful", -0.95);
        negativeWords.put("hate", -0.95);
        negativeWords.put("useless", -0.9);
        negativeWords.put("worst", -1.0);
        
        String lowerText = text.toLowerCase();
        double score = 0;
        int count = 0;
        
        for (Map.Entry<String, Double> entry : positiveWords.entrySet()) {
            if (lowerText.contains(entry.getKey())) {
                score += entry.getValue();
                count++;
            }
        }
        
        for (Map.Entry<String, Double> entry : negativeWords.entrySet()) {
            if (lowerText.contains(entry.getKey())) {
                score += entry.getValue();
                count++;
            }
        }
        
        return count > 0 ? score / count : 0;
    }
    
    /**
     * Extract entities from query
     */
    public Map<String, String> extractEntities(String query) {
        Map<String, String> entities = new HashMap<>();
        
        // Extract amount
        Matcher amountMatcher = AMOUNT_PATTERN.matcher(query);
        if (amountMatcher.find()) {
            entities.put("amount", amountMatcher.group(1));
        }
        
        // Extract bill ID
        Matcher billMatcher = BILL_ID_PATTERN.matcher(query);
        if (billMatcher.find()) {
            entities.put("bill_id", billMatcher.group(1));
        }
        
        // Extract phone
        Matcher phoneMatcher = PHONE_PATTERN.matcher(query);
        if (phoneMatcher.find()) {
            entities.put("phone", phoneMatcher.group(1));
        }
        
        // Extract date
        Matcher dateMatcher = DATE_PATTERN.matcher(query);
        if (dateMatcher.find()) {
            entities.put("date", dateMatcher.group(1));
        }
        
        return entities;
    }
    
    /**
     * Generate personalized suggestions based on user behavior
     */
    public List<String> generateSuggestions() {
        if (currentUser == null) {
            return Arrays.asList(
                "💡 Suggestion: Register now to access all features!",
                "💡 Tip: You can pay multiple bills at once!"
            );
        }
        
        List<String> suggestions = new ArrayList<>();
        
        // Check for unpaid bills
        List<Bill> unpaidBills = billService.getUserBills(currentUser.getUserId()).stream()
            .filter(b -> b.getBillStatus() == Bill.BillStatus.UNPAID)
            .collect(Collectors.toList());
        
        if (!unpaidBills.isEmpty()) {
            suggestions.add(String.format(
                "💡 You have %d unpaid bills. Pay them to avoid late fees!",
                unpaidBills.size()
            ));
        }
        
        // Check for low wallet balance
        if (currentUser.getWalletBalance().compareTo(new BigDecimal("100")) < 0) {
            suggestions.add("💡 Your wallet balance is low. Recharge now to continue!");
        }
        
        // Check for overdue bills
        List<Bill> overdueBills = unpaidBills.stream()
            .filter(b -> b.getBillStatus() == Bill.BillStatus.OVERDUE)
            .collect(Collectors.toList());
        
        if (!overdueBills.isEmpty()) {
            suggestions.add("⚠️ You have overdue bills. Please settle them immediately!");
        }
        
        // General suggestions
        if (suggestions.isEmpty()) {
            suggestions.add("✨ All clear! You're all set with your bills.");
            suggestions.add("💡 Tip: Enable notifications to never miss a bill deadline!");
        }
        
        return suggestions;
    }
    
    /**
     * Get conversation context
     */
    public Map<String, Object> getSessionContext() {
        return new HashMap<>(sessionContext);
    }
    
    /**
     * Clear conversation context
     */
    public void clearSessionContext() {
        sessionContext.clear();
    }
    
    /**
     * Get conversation history
     */
    public String getConversationHistory() {
        return conversationHistory.toString();
    }
    
    /**
     * Clear conversation history
     */
    public void clearConversationHistory() {
        conversationHistory = new StringBuilder();
    }
    
    /**
     * Set current user
     */
    public void setCurrentUser(User user) {
        this.currentUser = user;
    }
    
    /**
     * Get last detected intent
     */
    public String getLastIntent() {
        return lastIntent;
    }
    
    /**
     * Get time since last interaction
     */
    public long getMinutesSinceLastInteraction() {
        return java.time.temporal.ChronoUnit.MINUTES
            .between(lastInteraction, LocalDateTime.now());
    }
    
    /**
     * Check if session is idle (5+ minutes)
     */
    public boolean isSessionIdle() {
        return getMinutesSinceLastInteraction() >= 5;
    }
    
    /**
     * Handle session timeout
     */
    public String handleSessionTimeout() {
        return "⏱️ Your session has been idle for a while. " +
               "Please login again to continue. Type 'login' to get started!";
    }
    
    /**
     * Validate user before processing sensitive operations
     */
    public boolean validateUserForOperation(String operation) {
        if (currentUser == null) {
            return false;
        }
        
        // Check session timeout
        if (isSessionIdle()) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Generate analytics report
     */
    public String generateAnalyticsReport() {
        if (currentUser == null) {
            return "No user logged in.";
        }
        
        List<Transaction> transactions = transactionService
            .getRecentTransactions(currentUser.getUserId(), 100);
        
        BigDecimal totalSpent = transactions.stream()
            .map(Transaction::getAmount)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        long paymentCount = transactions.stream()
            .filter(t -> t.getTransactionType() == Transaction.TransactionType.PAYMENT)
            .count();
        
        return String.format(
            "📊 YOUR ANALYTICS:\n" +
            "Total Transactions: %d\n" +
            "Total Amount Spent: ₹%.2f\n" +
            "Payments Made: %d\n" +
            "Average per Transaction: ₹%.2f\n",
            transactions.size(),
            totalSpent,
            paymentCount,
            transactions.isEmpty() ? 0 : totalSpent.divide(
                new BigDecimal(transactions.size()), 2, java.math.RoundingMode.HALF_UP)
        );
    }
}