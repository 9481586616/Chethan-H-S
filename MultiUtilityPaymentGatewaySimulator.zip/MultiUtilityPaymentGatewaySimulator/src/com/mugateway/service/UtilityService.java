package com.mugateway.service;

import com.mugateway.dao.UtilityDAO;
import com.mugateway.model.Utility;
import com.mugateway.model.Utility.UtilityType;

import java.util.List;

public class UtilityService {
    private final UtilityDAO utilityDAO;

    public UtilityService() {
        this.utilityDAO = new UtilityDAO();
    }

    // CREATE - Add new utility
    public boolean addUtility(Utility utility) {
        if (utility.getUtilityName() == null || utility.getUtilityName().trim().isEmpty()) {
            System.out.println("❌ Utility name is required!");
            return false;
        }
        
        if (utility.getUtilityType() == null) {
            System.out.println("❌ Utility type is required!");
            return false;
        }
        
        boolean success = utilityDAO.createUtility(utility);
        if (success) {
            System.out.println("✅ Utility added successfully!");
        }
        return success;
    }

    // READ - Get utility by ID
    public Utility getUtilityById(int utilityId) {
        return utilityDAO.getUtilityById(utilityId);
    }

    // READ - Get all utilities
    public List<Utility> getAllUtilities() {
        return utilityDAO.getAllUtilities();
    }

    // READ - Get utilities by type
    public List<Utility> getUtilitiesByType(UtilityType type) {
        return utilityDAO.getUtilitiesByType(type);
    }

    // UPDATE - Update utility
    public boolean updateUtility(Utility utility) {
        if (utility.getUtilityId() <= 0) {
            System.out.println("❌ Invalid utility ID!");
            return false;
        }
        
        boolean success = utilityDAO.updateUtility(utility);
        if (success) {
            System.out.println("✅ Utility updated successfully!");
        }
        return success;
    }

    // DELETE - Deactivate utility
    public boolean deactivateUtility(int utilityId) {
        boolean success = utilityDAO.deactivateUtility(utilityId);
        if (success) {
            System.out.println("✅ Utility deactivated successfully!");
        }
        return success;
    }

    // DELETE - Remove utility permanently
    public boolean deleteUtility(int utilityId) {
        boolean success = utilityDAO.deleteUtility(utilityId);
        if (success) {
            System.out.println("✅ Utility deleted successfully!");
        }
        return success;
    }

    // Display all utilities in formatted table
    public void displayAllUtilities() {
        List<Utility> utilities = getAllUtilities();
        
        if (utilities.isEmpty()) {
            System.out.println("No utilities found.");
            return;
        }
        
        String line = "═".repeat(90);
        System.out.println("\n" + line);
        System.out.println("║ " + String.format("%-3s │ %-25s │ %-15s │ %-20s │ %-8s", 
            "ID", "UTILITY NAME", "TYPE", "PROVIDER", "STATUS") + " ║");
        System.out.println(line);
        
        for (Utility utility : utilities) {
            System.out.println(utility);
        }
        
        System.out.println(line);
        System.out.println("Total utilities: " + utilities.size());
    }
}