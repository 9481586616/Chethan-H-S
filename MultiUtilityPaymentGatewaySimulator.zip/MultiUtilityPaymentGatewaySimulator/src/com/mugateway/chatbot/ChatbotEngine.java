package com.mugateway.chatbot;

import com.mugateway.model.User;
import com.mugateway.service.*;

import java.util.*;

public class ChatbotEngine {
    private final UserService userService;
    private final BillService billService;
    private final PaymentService paymentService;
    private final TransactionService transactionService;
    private User currentUser;
    
    private static final Map<String, String[]> KEYWORDS = new HashMap<>();
    
    static {
        KEYWORDS.put("GREETING", new String[]{"hi", "hello", "hey", "good morning", "good evening"});
        KEYWORDS.put("BALANCE", new String[]{"balance", "wallet", "money", "funds"});
        KEYWORDS.put("BILL", new String[]{"bill", "bills", "pending", "due", "unpaid"});
        KEYWORDS.put("PAYMENT", new String[]{"pay", "payment", "payments", "paid"});
        KEYWORDS.put("HISTORY", new String[]{"history", "transactions", "statement"});
        KEYWORDS.put("HELP", new String[]{"help", "support", "assist", "how to"});
        KEYWORDS.put("PROFILE", new String[]{"profile", "account", "details", "info"});
        KEYWORDS.put("RECHARGE", new String[]{"recharge", "topup", "add money", "add balance"});
        KEYWORDS.put("UTILITY", new String[]{"utility", "utilities", "services", "electricity", "water", "gas"});
        KEYWORDS.put("EXIT", new String[]{"bye", "exit", "quit", "goodbye", "close"});
    }

    public ChatbotEngine() {
        this.userService = new UserService();
        this.billService = new BillService();
        this.paymentService = new PaymentService();
        this.transactionService = new TransactionService();
    }

    public void setCurrentUser(User user) {
        this.currentUser = user;
    }

    public String processQuery(String input) {
        if (input == null || input.trim().isEmpty()) {
            return "I didn't catch that. Could you please repeat?";
        }
        
        String lowerInput = input.toLowerCase().trim();
        String intent = detectIntent(lowerInput);
        
        return generateResponse(intent, lowerInput);
    }

    private String detectIntent(String input) {
        for (Map.Entry<String, String[]> entry : KEYWORDS.entrySet()) {
            for (String keyword : entry.getValue()) {
                if (input.contains(keyword)) {
                    return entry.getKey();
                }
            }
        }
        return "UNKNOWN";
    }

    private String generateResponse(String intent, String input) {
        switch (intent) {
            case "GREETING":
                return getGreetingResponse();
            
            case "BALANCE":
                return getBalanceResponse();
            
            case "BILL":
                return getBillResponse();
            
            case "PAYMENT":
                return getPaymentResponse();
            
            case "HISTORY":
                return getHistoryResponse();
            
            case "HELP":
                return getHelpResponse();
            
            case "PROFILE":
                return getProfileResponse();
            
            case "RECHARGE":
                return getRechargeResponse();
            
            case "UTILITY":
                return getUtilityResponse();
            
            case "EXIT":
                return "Goodbye! Thank you for using MU Gateway. Have a great day! 👋";
            
            default:
                return getUnknownResponse();
        }
    }

    private String getGreetingResponse() {
        String name = currentUser != null ? currentUser.getFullName() : "Guest";
        String[] greetings = {
            "Hello " + name + "! 👋 How can I help you today?",
            "Hi there, " + name + "! Welcome to MU Gateway. What would you like to do?",
            "Hey " + name + "! Great to see you. Need help with bills or payments?"
        };
        return greetings[new Random().nextInt(greetings.length)];
    }

    private String getBalanceResponse() {
        if (currentUser == null) {
            return "Please login to check your wallet balance.";
        }
        
        return String.format(
            "💰 Your wallet balance is: ₹%.2f\n\n" +
            "Would you like to:\n" +
            "• Add money to wallet\n" +
            "• View transaction history\n" +
            "• Pay a bill",
            currentUser.getWalletBalance()
        );
    }

    private String getBillResponse() {
        if (currentUser == null) {
            return "Please login to view your bills.";
        }
        
        var bills = billService.getUnpaidBills(currentUser.getUserId());
        
        if (bills.isEmpty()) {
            return "✅ Great news! You have no pending bills. All your bills are paid!";
        }
        
        StringBuilder response = new StringBuilder();
        response.append("📋 You have ").append(bills.size()).append(" pending bill(s):\n\n");
        
        double total = 0;
        for (var bill : bills) {
            response.append(String.format("• %s - ₹%.2f (Due: %s)\n",
                bill.getUtilityName(), bill.getBillAmount(), bill.getDueDate()));
            total += bill.getBillAmount().doubleValue();
        }
        
        response.append(String.format("\nTotal Amount Due: ₹%.2f", total));
        return response.toString();
    }

    private String getPaymentResponse() {
        if (currentUser == null) {
            return "Please login to make a payment.";
        }
        
        return "💳 Payment Options:\n\n" +
               "1. Pay a specific bill\n" +
               "2. Make a direct payment\n" +
               "3. Recharge wallet\n" +
               "4. View payment history\n\n" +
               "Choose an option from the menu.";
    }

    private String getHistoryResponse() {
        if (currentUser == null) {
            return "Please login to view your transaction history.";
        }
        
        var transactions = transactionService.getRecentTransactions(currentUser.getUserId(), 5);
        
        if (transactions.isEmpty()) {
            return "No transaction history found yet.";
        }
        
        StringBuilder response = new StringBuilder();
        response.append("📊 Recent Transactions (Last 5):\n\n");
        
        for (var txn : transactions) {
            response.append(String.format("• %s - %s ₹%.2f\n",
                txn.getTransactionType(),
                txn.getDescription(),
                txn.getAmount()));
        }
        
        return response.toString();
    }

    private String getHelpResponse() {
        return "🆘 HELP MENU\n\n" +
               "Available Commands:\n" +
               "• Check Balance - View wallet balance\n" +
               "• View Bills - See all pending bills\n" +
               "• Pay Bill - Make a payment\n" +
               "• Transaction History - View past transactions\n" +
               "• Profile - View account details\n" +
               "• Utilities - Browse available services\n" +
               "• Recharge - Add money to wallet\n\n" +
               "Contact Support:\n" +
               "📧 Email: support@mugateway.com\n" +
               "📱 Phone: 1-800-MU-GATEWAY";
    }

    private String getProfileResponse() {
        if (currentUser == null) {
            return "Please login to view your profile.";
        }
        
        return String.format(
            "👤 PROFILE INFORMATION\n\n" +
            "Name: %s\n" +
            "Username: %s\n" +
            "Email: %s\n" +
            "Phone: %s\n" +
            "Wallet: ₹%.2f\n" +
            "Status: %s\n\n" +
            "Would you like to update your profile?",
            currentUser.getFullName(),
            currentUser.getUsername(),
            currentUser.getEmail(),
            currentUser.getPhone(),
            currentUser.getWalletBalance(),
            currentUser.isActive() ? "Active" : "Inactive"
        );
    }

    private String getRechargeResponse() {
        if (currentUser == null) {
            return "Please login to recharge your wallet.";
        }
        
        return "💳 Wallet Recharge\n\n" +
               "Available Payment Methods:\n" +
               "• Credit Card\n" +
               "• Debit Card\n" +
               "• Net Banking\n" +
               "• UPI\n" +
               "• Cash (Offline)\n\n" +
               "Enter the amount you want to add to your wallet.";
    }

    private String getUtilityResponse() {
        return "⚡ AVAILABLE UTILITIES\n\n" +
               "1. Electricity\n" +
               "2. Water Supply\n" +
               "3. Gas Connection\n" +
               "4. Mobile Recharge\n" +
               "5. Internet Bill\n" +
               "6. DTH Recharge\n\n" +
               "Select a utility to view or pay bills.";
    }

    private String getUnknownResponse() {
        String[] responses = {
            "I'm not sure I understand. Could you rephrase that?",
            "Sorry, I didn't get that. Try asking me about bills, payments, or balance!",
            "That's beyond my current knowledge. Try the main menu for more options.",
            "Hmm, I'm not sure about that. Would you like help with something else?"
        };
        return responses[new Random().nextInt(responses.length)];
    }
}