package com.mugateway.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class Transaction {
    private int transactionId;
    private int userId;
    private Integer paymentId;
    private TransactionType transactionType;
    private BigDecimal amount;
    private BigDecimal balanceBefore;
    private BigDecimal balanceAfter;
    private String description;
    private Timestamp transactionDate;
    
    // For JOIN queries
    private String username;
    private String paymentRef;

    public enum TransactionType {
        PAYMENT, REFUND, WALLET_RECHARGE, TRANSFER
    }

    // Default Constructor
    public Transaction() {}

    // Parameterized Constructor
    public Transaction(int userId, Integer paymentId, TransactionType transactionType, 
                      BigDecimal amount, String description) {
        this.userId = userId;
        this.paymentId = paymentId;
        this.transactionType = transactionType;
        this.amount = amount;
        this.description = description;
    }

    // Getters and Setters
    public int getTransactionId() { return transactionId; }
    public void setTransactionId(int transactionId) { this.transactionId = transactionId; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public Integer getPaymentId() { return paymentId; }
    public void setPaymentId(Integer paymentId) { this.paymentId = paymentId; }

    public TransactionType getTransactionType() { return transactionType; }
    public void setTransactionType(TransactionType transactionType) { this.transactionType = transactionType; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }

    public BigDecimal getBalanceBefore() { return balanceBefore; }
    public void setBalanceBefore(BigDecimal balanceBefore) { this.balanceBefore = balanceBefore; }

    public BigDecimal getBalanceAfter() { return balanceAfter; }
    public void setBalanceAfter(BigDecimal balanceAfter) { this.balanceAfter = balanceAfter; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Timestamp getTransactionDate() { return transactionDate; }
    public void setTransactionDate(Timestamp transactionDate) { this.transactionDate = transactionDate; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPaymentRef() { return paymentRef; }
    public void setPaymentRef(String paymentRef) { this.paymentRef = paymentRef; }

    @Override
    public String toString() {
        return String.format(
            "║ %-5d │ %-15s │ ₹%-12.2f │ ₹%-12.2f │ %-20s │ %-19s ║",
            transactionId, transactionType, amount, balanceAfter,
            description != null && description.length() > 20 ? 
                description.substring(0, 17) + "..." : description,
            transactionDate
        );
    }
}