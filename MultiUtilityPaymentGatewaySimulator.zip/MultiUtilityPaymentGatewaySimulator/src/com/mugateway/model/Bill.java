package com.mugateway.model;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;

public class Bill {
    private int billId;
    private int userId;
    private int utilityId;
    private String billNumber;
    private BigDecimal billAmount;
    private Date dueDate;
    private BillStatus billStatus;
    private Timestamp generatedDate;
    private Timestamp paidDate;
    
    // For JOIN queries
    private String username;
    private String utilityName;

    public enum BillStatus {
        UNPAID, PAID, OVERDUE, CANCELLED
    }

    // Default Constructor
    public Bill() {
        this.billStatus = BillStatus.UNPAID;
    }

    // Parameterized Constructor
    public Bill(int userId, int utilityId, String billNumber, BigDecimal billAmount, Date dueDate) {
        this();
        this.userId = userId;
        this.utilityId = utilityId;
        this.billNumber = billNumber;
        this.billAmount = billAmount;
        this.dueDate = dueDate;
    }

    // Getters and Setters
    public int getBillId() { return billId; }
    public void setBillId(int billId) { this.billId = billId; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public int getUtilityId() { return utilityId; }
    public void setUtilityId(int utilityId) { this.utilityId = utilityId; }

    public String getBillNumber() { return billNumber; }
    public void setBillNumber(String billNumber) { this.billNumber = billNumber; }

    public BigDecimal getBillAmount() { return billAmount; }
    public void setBillAmount(BigDecimal billAmount) { this.billAmount = billAmount; }

    public Date getDueDate() { return dueDate; }
    public void setDueDate(Date dueDate) { this.dueDate = dueDate; }

    public BillStatus getBillStatus() { return billStatus; }
    public void setBillStatus(BillStatus billStatus) { this.billStatus = billStatus; }

    public Timestamp getGeneratedDate() { return generatedDate; }
    public void setGeneratedDate(Timestamp generatedDate) { this.generatedDate = generatedDate; }

    public Timestamp getPaidDate() { return paidDate; }
    public void setPaidDate(Timestamp paidDate) { this.paidDate = paidDate; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getUtilityName() { return utilityName; }
    public void setUtilityName(String utilityName) { this.utilityName = utilityName; }

    @Override
    public String toString() {
        return String.format(
            "╔══════════════════════════════════════════════════╗\n" +
            "║                   BILL DETAILS                   ║\n" +
            "╠══════════════════════════════════════════════════╣\n" +
            "║ Bill ID      : %-33d ║\n" +
            "║ Bill Number  : %-33s ║\n" +
            "║ Utility      : %-33s ║\n" +
            "║ Amount       : ₹%-32.2f ║\n" +
            "║ Due Date     : %-33s ║\n" +
            "║ Status       : %-33s ║\n" +
            "╚══════════════════════════════════════════════════╝",
            billId, billNumber, utilityName != null ? utilityName : "N/A",
            billAmount, dueDate, billStatus
        );
    }
}