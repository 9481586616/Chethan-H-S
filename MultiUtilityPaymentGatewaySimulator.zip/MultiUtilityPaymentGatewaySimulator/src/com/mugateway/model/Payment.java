package com.mugateway.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class Payment {
    private int paymentId;
    private int userId;
    private Integer billId;
    private BigDecimal paymentAmount;
    private PaymentMode paymentMode;
    private PaymentStatus paymentStatus;
    private String transactionRef;
    private boolean isOffline;
    private Timestamp paymentDate;
    private String remarks;
    
    // For JOIN queries
    private String username;
    private String billNumber;

    public enum PaymentMode {
        UPI, CREDIT_CARD, DEBIT_CARD, NET_BANKING, WALLET, CASH
    }

    public enum PaymentStatus {
        PENDING, SUCCESS, FAILED, REFUNDED
    }

    // Default Constructor
    public Payment() {
        this.paymentStatus = PaymentStatus.PENDING;
        this.isOffline = false;
    }

    // Parameterized Constructor
    public Payment(int userId, Integer billId, BigDecimal paymentAmount, PaymentMode paymentMode) {
        this();
        this.userId = userId;
        this.billId = billId;
        this.paymentAmount = paymentAmount;
        this.paymentMode = paymentMode;
    }

    // Getters and Setters
    public int getPaymentId() { return paymentId; }
    public void setPaymentId(int paymentId) { this.paymentId = paymentId; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public Integer getBillId() { return billId; }
    public void setBillId(Integer billId) { this.billId = billId; }

    public BigDecimal getPaymentAmount() { return paymentAmount; }
    public void setPaymentAmount(BigDecimal paymentAmount) { this.paymentAmount = paymentAmount; }

    public PaymentMode getPaymentMode() { return paymentMode; }
    public void setPaymentMode(PaymentMode paymentMode) { this.paymentMode = paymentMode; }

    public PaymentStatus getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(PaymentStatus paymentStatus) { this.paymentStatus = paymentStatus; }

    public String getTransactionRef() { return transactionRef; }
    public void setTransactionRef(String transactionRef) { this.transactionRef = transactionRef; }

    public boolean isOffline() { return isOffline; }
    public void setOffline(boolean offline) { isOffline = offline; }

    public Timestamp getPaymentDate() { return paymentDate; }
    public void setPaymentDate(Timestamp paymentDate) { this.paymentDate = paymentDate; }

    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getBillNumber() { return billNumber; }
    public void setBillNumber(String billNumber) { this.billNumber = billNumber; }

    @Override
    public String toString() {
        return String.format(
            "╔══════════════════════════════════════════════════╗\n" +
            "║                 PAYMENT DETAILS                  ║\n" +
            "╠══════════════════════════════════════════════════╣\n" +
            "║ Payment ID   : %-33d ║\n" +
            "║ Transaction  : %-33s ║\n" +
            "║ Amount       : ₹%-32.2f ║\n" +
            "║ Mode         : %-33s ║\n" +
            "║ Status       : %-33s ║\n" +
            "║ Date         : %-33s ║\n" +
            "║ Offline      : %-33s ║\n" +
            "╚══════════════════════════════════════════════════╝",
            paymentId, transactionRef, paymentAmount, paymentMode,
            paymentStatus, paymentDate, isOffline ? "Yes" : "No"
        );
    }
}