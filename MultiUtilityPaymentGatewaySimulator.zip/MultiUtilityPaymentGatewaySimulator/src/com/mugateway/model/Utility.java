package com.mugateway.model;

import java.sql.Timestamp;

public class Utility {
    private int utilityId;
    private String utilityName;
    private UtilityType utilityType;
    private String providerName;
    private String description;
    private boolean isActive;
    private Timestamp createdAt;

    public enum UtilityType {
        ELECTRICITY, WATER, GAS, MOBILE_RECHARGE, INTERNET, DTH
    }

    // Default Constructor
    public Utility() {
        this.isActive = true;
    }

    // Parameterized Constructor
    public Utility(String utilityName, UtilityType utilityType, String providerName, String description) {
        this();
        this.utilityName = utilityName;
        this.utilityType = utilityType;
        this.providerName = providerName;
        this.description = description;
    }

    // Getters and Setters
    public int getUtilityId() { return utilityId; }
    public void setUtilityId(int utilityId) { this.utilityId = utilityId; }

    public String getUtilityName() { return utilityName; }
    public void setUtilityName(String utilityName) { this.utilityName = utilityName; }

    public UtilityType getUtilityType() { return utilityType; }
    public void setUtilityType(UtilityType utilityType) { this.utilityType = utilityType; }

    public String getProviderName() { return providerName; }
    public void setProviderName(String providerName) { this.providerName = providerName; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    @Override
    public String toString() {
        return String.format(
            "║ %-3d │ %-25s │ %-15s │ %-20s │ %-8s ║",
            utilityId, utilityName, utilityType, providerName, isActive ? "Active" : "Inactive"
        );
    }
}